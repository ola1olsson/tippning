<table BGCOLOR="#FFFFFF" border="0" width="100%" height="100%">
<tr>
<td align="center" valign="top">
<br>
<?
if(session_is_registered('permission') && $_SESSION['permission']) {
echo '<span class=rubrik>Min profil<br><br></span>';
		

//-----
if($cmd == 'passwd') {
	if($_POST['register'] == 'register') {
		// SAVE PASSWORD
		$passres = mysql_query("SELECT password FROM users WHERE ID = '".$_SESSION['userID']."';");
		if(mysql_result($passres,0,'password') == $_POST['oldPass'] && $_POST['newPass1'] == $_POST['newPass2']) {
			mysql_query("UPDATE users SET password = '".$_POST['newPass1']."' WHERE ID = '".$_SESSION['userID']."';");
			echo '<span class=rubrik3>Det nya l�senordet sparades!<br></span><br>'.
					'<input type=button value="Ok" onClick="document.location=\'default.php?page=default\';" class=btn>';
		} else {
			// ERROR PASSWORD
			echo '<span class=rubrik3>Fel uppstod vid sparandet! F�rs�k igen...<br></span>'.
				'<input type=button class=btn value="F�rs�k igen..." onClick="document.location=\'index.php?page=profile&cmd=passwd\';">';
		}
	} else {
		// ENTER NEW PASSWORD
		echo 'Gammalt l�senord:<br><input type=password name=oldPass><br><br><br>'.
			'Nytt l�senord:<br><input type=password name=newPass1><br><br>'.
			'Upprepa l�senord:<br><input type=password name=newPass2><br><br>'.
			'<input type=hidden name=register value=register>'.
			'<input type=button value="Spara l�senord" class=btn onClick="this.form.action=\'index.php?page=profile&cmd=passwd\'; this.form.submit();">';
		
	}
} else {
	if($_POST['register'] == 'register') {
		// SPARA INST�LLNINGAR	
		mysql_query("UPDATE users SET ".
					"givenName = '".$_POST['givenName']."', ".
					"familyName = '".$_POST['familyName']."', ".
					"emailAddress = '".$_POST['emailAddress']."', ".
					"phoneNumber = '".$_POST['phoneNumber']."', ".
					"Company = '".$_POST['Company']."', ".
					"city = '".$_POST['city']."' WHERE id = '".$_SESSION['userID']."';") or die(mysql_error());
		echo 'Profil sparad!<br>'.
				'<input type=button class=btn value="Tillbaka" onClick="document.location=\'index.php?page=default\';">';
					
		
	} else {
		// STANDARD
		$dbuser = mysql_fetch_array(mysql_query("SELECT * FROM users WHERE id = '".$_SESSION['userID']."';"), MYSQL_ASSOC);
		
		?>
		<table border="0" cellspacing="30">
		<tr valign="top">
			<td><img src="./pic/users/<?=$_SESSION['foto'];?>" width="150" height="150"></td>
			<td rowspan="2">
				<table border=0 cellspacing=5 cellpadding=0 style="width:200px;">
					<tr>
						<td>F�rnamn</td>
						<td colspan="2"><input type="text" style="width:200px;" name="givenName" value="<?=$dbuser['givenName'];?>"></td>
					</tr>	
					<tr>
						<td>Efternamn</td>
						<td colspan="2"><input type="text" style="width:200px;" name="familyName" value="<?=$dbuser['familyName'];?>"></td>
					</tr>
					<tr>
						<td>F�retag</td>
						<td colspan="2"><input type="text" style="width:200px;" name="Company" value="<?=$dbuser['Company'];?>"></td>
					</tr>
					<tr>
						<td>Telefon</td>
						<td colspan="2"><input type="text" style="width:200px;" name="phoneNumber" value="<?=$dbuser['phoneNumber'];?>"></td>
					</tr>
					<tr>
						<td>Ort</td>
						<td colspan="2"><input type="text" style="width:200px;" name="city" value="<?=$dbuser['city'];?>"></td>
					</tr>
					<tr>
						<td>Email</td>
						<td colspan="2"><input type="text" style="width:200px;" name="emailAddress" value="<?=$dbuser['emailAddress'];?>"></td>
					</tr>
					<tr>
						<input type="hidden" name="register" value="register">
						<td></td>
						<td align="left"><input type="button" value="Tillbaka" onClick="history.back();" class="btn"></td>
						<td align="right"><input type="button" value="Spara profil" onClick="this.form.action='index.php?sida=profil'; this.form.submit();" class="btn"></td>
					</tr>
				</table>
				<br><br>
				
			</td>
		<tr>
			<td align="center"><h4><?=$dbuser['user'];?></h4></td>
		</tr>
		</tr>
		</table>
		<?
	}
}
} else
	echo 'Permission denied!';
?>



</td>
</tr>
</table>
