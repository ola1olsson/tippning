


<?
// Om dagens datum inte �r mer 2008-06-01 & du har tilll�telse samt betalat eller att du �r admin s� �r det ok att l�gga in sin tippning p� sidan.
$last_date = $last_bet_day;
 if(session_is_registered('permission') && $_SESSION['permission'] && $_SESSION['betalt'] == 1 && (date('Y-m-d')<$last_bet_day || $_SESSION['admin'])) {
 ?>

<table BGCOLOR="#FFFFFF" border="0" width="100%" height="100%">
<tr>
<td align="center">

<br>
<span class="rubrik4"><b>Tippningen</b></span>
<br>
<br>

<?
$err = false;

$grundspel_max = 24;
$slutspel_max = 31;

//----------------------------------------------------------------------------------------------------------------------
if(isset($_POST['match'])) { 				
	//echo 'POST ISSET<br>';
	$_SESSION['match'] = $_POST['match'];
	
	// ERROR CONTROL, kollar om det �r n�gra fel i tippningen, om n�got �r gl�mt.
	
	for($i=1; $i<=$grundspel_max; $i++) {
		if($_SESSION['match'][$i] == '') 
			$err = true;	
			
	}
	for($i=$grundspel_max + 1; $i<=$slutspel_max; $i++) {
		if($_SESSION['match'][$i][0]=='' || $_SESSION['match'][$i][1]=='' || $_SESSION['match'][$i][2]=='')
			$err = true;	
	}

	if($_SESSION['match'][32]=='' || $_SESSION['match'][33]=='' || $_SESSION['match'][34][0]=='' || $_SESSION['match'][34][1]=='') 
			$err = true;	
			
	
	//echo 'ERRORS FOUND: ';
	//if($err) 
	//	echo 'YES';
	//else
	//	echo 'NO';
	echo '<br><br>';
	
//----------------------------------------------------------------------------------------------------------------------	
//																									Annars
} else {										
	//echo 'POST !ISSET<br>';
	$restip = mysql_query("SELECT * FROM tippning WHERE id = '".$_SESSION['userID']."';") or die(mysql_error());
	
	if($tipp = mysql_fetch_array($restip, MYSQL_ASSOC)) {
		for($i=1; $i<=$grundspel_max; $i++) {
			$debug .= 'm'.$i.'='.$tipp['m'.$i].',';
			$_SESSION['match'][$i] = $tipp['m'.$i];	
		}
		for($i=$grundspel_max + 1; $i<=$slutspel_max; $i++) {
			$_SESSION['match'][$i][0] = $tipp['m'.$i];
			$_SESSION['match'][$i][1] = $tipp['m'.$i.'a'];
			$_SESSION['match'][$i][2] = $tipp['m'.$i.'b'];
		}
		$_SESSION['match'][$slutspel_max + 1] = $tipp['m32a'];
		$_SESSION['match'][$slutspel_max + 2] = $tipp['m33a'];
		$_SESSION['match'][$slutspel_max + 3][0] = $tipp['m34a'];
		$_SESSION['match'][$slutspel_max + 3][1] = $tipp['m34b'];
	} 
	
}

//----------------------------------------------------------------------------------------------------------------------	
// 																								REGISTRERA I DATABASEN
if(isset($_POST['match']) && !$err && date('Y-m-d')<$last_date) {
	// REGISTRERA I DATABASEN	
	/** PRINT POST
	
	for($i=1; $i<=48; $i++) {
		echo 'M'.$i.': '.$_SESSION['match'][$i].'<br>';	
	}
	for($i=49; $i<=64; $i++) {
		echo 'M'.$i.': '.$_SESSION['match'][$i][0].'<br>';
		echo 'M'.$i.'A: '.$_SESSION['match'][$i][1].'<br>';	
		echo 'M'.$i.'B: '.$_SESSION['match'][$i][2].'<br>';			
	}
	echo 'M65: '.$_SESSION['match'][65].'<br>';	
	echo 'M66: '.$_SESSION['match'][66].'<br>';	
	echo 'M67A: '.$_SESSION['match'][67][0].'<br>';	
	echo 'M67B: '.$_SESSION['match'][67][1].'<br>';	
	*/

	// INSERT INTO DATABASE
	$user_chk = mysql_query("SELECT id FROM tippning WHERE id = '".$_SESSION['userID']."';") or die(mysql_error());
	if(mysql_num_rows($user_chk)>0) {
		// UPDATE TIP IN DATABASE	
		$query = "UPDATE tippning SET ";
		for($i=1; $i<=$grundspel_max; $i++) {
			 $query .= "m".$i."='".$_SESSION['match'][$i]."', ";
		}
		for($i=$grundspel_max + 1; $i<=$slutspel_max; $i++) {
			$query .= "m".$i."='".$_SESSION['match'][$i][0]."', ";
			$query .= "m".$i."a='".$_SESSION['match'][$i][1]."', ";
			$query .= "m".$i."b='".$_SESSION['match'][$i][2]."', ";
		}
		$query .= "m".($slutspel_max + 1)."a='".$_SESSION['match'][($slutspel_max + 1)]."', ";
		$query .= "m".($slutspel_max + 2)."a='".$_SESSION['match'][($slutspel_max + 2)]."', ";
		$query .= "m".($slutspel_max + 3)."a='".$_SESSION['match'][($slutspel_max + 3)][0]."', ";	
		$query .= "m".($slutspel_max + 3)."b='".$_SESSION['match'][($slutspel_max + 3)][1]."'";	
		
		$query .= " WHERE id = '".$_SESSION['userID']."';";
	} else {
		// INSERT TIP INTO DATABASE
		$query = "INSERT INTO tippning (";
		$query .= 'id, ';
		for($i=1; $i<=$grundspel_max; $i++) {
			$query .= 'm'.$i.', ';
		}
		for($i=$grundspel_max + 1; $i<=$slutspel_max; $i++) {
			$query .= 'm'.$i.', m'.$i.'a, m'.$i.'b, ';		
		}
		$query .= 'm'.($slutspel_max + 1).'a, m'.($slutspel_max + 2).'a, m'.($slutspel_max + 3).'a, m'.($slutspel_max + 3).'b) ';
		$query .= 'VALUES (';
		$query .= "'".$_SESSION['userID']."', ";
		for($i=1; $i<=$grundspel_max; $i++) {
			$query.= "'".$_SESSION['match'][$i]."', ";	
		}
		for($i=$grundspel_max + 1; $i<=$slutspel_max; $i++) {
			for($k=0; $k<=2; $k++)
				$query .= "'".$_SESSION['match'][$i][$k]."', ";		
		}
		$query .= "'".$_SESSION['match'][($slutspel_max + 1)]."', ";
		$query .= "'".$_SESSION['match'][($slutspel_max + 2)]."', ";
		$query .= "'".$_SESSION['match'][($slutspel_max + 3)][0]."', ";	
		$query .= "'".$_SESSION['match'][($slutspel_max + 3)][1]."'";	
		$query .= ');';
		
		
	}
	//echo $query;
	mysql_query($query) or die(mysql_error());
	echo '<span class=rubrik2>Tippning registrerad!<br></span><br><input type=button class=btn value="Ok!" onClick="document.location=\'index.php?sida=tippning\';">';
	
} else {

// -----------------------------------------GRUNDSPEL-----------------------------------------
echo '<h3>Gruppspel</h3>';


$grundspel = Array('A','B','C','D');
foreach($grundspel AS $grupp) {
	$matcher = mysql_query("SELECT * FROM matcher WHERE hemma LIKE '".$grupp."%' AND borta LIKE '".$grupp."%' ORDER BY ID ASC;");
?>
	<table border=0 cellspacing=0 cellpadding=2>
	<tr>
		<td colspan=7 align="center"><span class="rubrik4"><b>Grupp <?=$grupp?></b></span></td>
	</tr>
	
		<tr class="rubrik">
		<td align="right">Match</td>
		<td align="right">Hemma</td>
		<td>-</td>
		<td align="left">Borta</td>
		<td align="center">1</td>
		<td align="center">X</td>
		<td align="center">2</td>
	</tr>
<?	
	while($match = mysql_fetch_array($matcher, MYSQL_ASSOC)) {
		$hemma = mysql_fetch_array(mysql_query("SELECT * FROM lag WHERE lag = '".$match['hemma']."';"), MYSQL_ASSOC);
		$borta = mysql_fetch_array(mysql_query("SELECT * FROM lag WHERE lag = '".$match['borta']."';"), MYSQL_ASSOC);
		if(!empty($_SESSION['match']) && $_SESSION['match'][$match['id']] == '') { 
			echo '<tr style="background-color: #FF0000;">';
			$err = true;
		} else {
			echo '<tr>';
		} 
 ?>
		<td align="center"><?=$match['id']?></td>
		<td align="right"><?=$hemma['land'] ?>&nbsp;<img src="./pic/flaggor/<?=$hemma['flagga']?>" align="absmiddle"></td>
		<td valign="center" align="center"> - </td>
		<td valign="center" align="left"><img src="./pic/flaggor/<?=$borta['flagga']?>" align="absmiddle">&nbsp;<?=$borta['land']?></td>
		<td align="center"><input type="radio" class="radio" name="<?='match['.$match['id'].']'?>" value="1"
		<?
		if($_SESSION['match'][$match['id']] == '1') 
		echo ' checked';
		?>
		>
		</td>
		<td align="center"><input type="radio" class="radio" name="<?='match['.$match['id'].']'?>" value="X"
		<?
		if($_SESSION['match'][$match['id']] == 'X') 
			echo ' checked';
		?>
		>
		</td>
		<td align="center"><input type="radio" class="radio" name="<?='match['.$match['id'].']'?>" value="2"
		<?
		if($_SESSION['match'][$match['id']] == '2') 
			 echo ' checked';
		?>
		>
		</td>
	</tr>
	<?
	}
	?>
	<tr>
		<td colspan=7 align="center"><hr align="center" style="width:96%; height:1px;" color="#6C261F"></td>
	</tr>
	</table>
<br>
<?
}
// -----------------------------------------GRUNDSPEL SLUT------------------------------------

// -----------------------------------------KVART B�RJAR -------------------------------------

?>

<h3>Kvartsfinaler</h3>

<table border="0" cellspacing="0" cellpadding="2">
	<tr class="rubrik">
		<td align="right">Match</td>
		<td width=150 align="center">Hemma</td>
		<td>-</td>
		<td width=150 align="center">Borta</td>
		<td align="center">1</td>
		<td align="center">-</td>
		<td align="center">2</td>
	</tr>
<?
/**
	groups f�rklaring:
	groups[i] -> i = gruppnummer
	groups[i][k] -> k(0) = hemma, k(1) = borta
*/

$groups[1][0] = 'A';
$groups[1][1] = 'B';
$groups[2][0] = 'B';
$groups[2][1] = 'A';
$groups[3][0] = 'C';
$groups[3][1] = 'D';
$groups[4][0] = 'D';
$groups[4][1] = 'C';

$match_offset = 24; // sista matchnumret i gruppspelet
$err = false;
for($match=1; $match<=4; $match++) {
	$hamtahemma = mysql_query("SELECT * FROM lag WHERE lag LIKE '".$groups[$match][0]."%';");
	$hamtaborta = mysql_query("SELECT * FROM lag WHERE lag LIKE '".$groups[$match][1]."%';");
	
	$matchnumber = $match + $match_offset;
?>	
	
	<tr>
		<td colspan="7" align="center"><span class="rubrik4"><b>Kvartsfinal <?=$match?></b></span><br><br></td>
	</tr>
	<tr
<?	// kollar s� att just denna match blivit tippad, annars f�rgar vi hela TR'n r�������d
	if(!empty($_SESSION['match']) && ($_SESSION['match'][$matchnumber][0] == '' || $_SESSION['match'][$matchnumber][1] == '' || $_SESSION['match'][$matchnumber][2] == '')) {
		echo '  style="background-color: #FF0000;"';
		$err = true;
	}
?>	>
		<td align="center"><?=$matchnumber?></td>
		<td><select style="width:100%;" name="<?='match['.$matchnumber.'][1]'?>">
			<option value="">---- V�lj lag ----
			
<?			
			while($alag = mysql_fetch_array($hamtahemma,MYSQL_ASSOC)) {
				echo '<option value="'.$alag['lag'].'"'; // h�r kan du anv�nda ID ist�llet om du vill, s� l�nge du anv�nder samma attribut som n�r du skall spara det i databasen
				if($_SESSION['match'][$matchnumber][1] == $alag['lag']) 
					echo ' selected';
				echo '>'.$alag['land'];
			}
?>
			</select>
		</td>
		<td align="center"> - </td>
		<td><select style="width:100%;" name="<?='match['.$matchnumber.'][2]'?>">
			<option value="">---- V�lj lag ----
<?
			while($blag = mysql_fetch_array($hamtaborta,MYSQL_ASSOC)) {
				echo '<option value="'.$blag['lag'].'"';
				if($_SESSION['match'][$matchnumber][2] == $blag['lag']) 
					echo ' selected';
				echo '>'.$blag['land'];
			}
?>
			</select>
		</td>
		<td align="center"><input type="radio" class="radio" name="<?='match['.$matchnumber.'][0]'?>" value="1"
<?
	// kolla om matchen redan �r tippad (och isf sparad i sessionen), i s� fall skall r�tt tippningen "checkas"
	if($_SESSION['match'][$matchnumber][0] == '1') echo ' checked';		
?>
		>
		</td>
		<td align="center"> - </td>
		<td align="center"><input type="radio" class="radio" name="<?='match['.$matchnumber.'][0]'?>" value="2"
<?
	if($_SESSION['match'][$matchnumber][0] == '2') echo ' checked';	
?>
		>
		</td>
	</tr>
	<tr>
		<td></td>
		<td>Vinnare grupp <?=$groups[$match][0]?></td>
		<td></td>
		<td>Andraplats grupp <?=$groups[$match][1]?></td>
	</tr>	
	<tr>
	<td colspan=7 align="center"><hr align="center" style="width:96%; height:1px;" color="#6C261F"></td>
	</tr>	
<?
}
?>

</table>
<br>
<br>
<br>
<?
// -------------------------------------------------------- KVART SLUT ---------------------------

// -------------------------------------------------------- SEMI B�RJAR --------------------------

?>

<h3>Semifinaler</h3>
<table border=0 cellspacing=0 cellpadding=2>
	<tr class="rubrik">
		<td align="right">Match</td>
		<td width=150 align="center">Hemma</td>
		<td>-</td><td width=150 align="center">Borta</td>
		<td align="center">1</td>
		<td align="center">-</td>
		<td align="center">2</td>
	</tr>
	
<?
// OPTIMERADE KVARTAR

$groups[1][0][0] = 'A';
$groups[1][0][1] = 'B';
$groups[1][1][0] = 'B';
$groups[1][1][1] = 'A';
$groups[2][0][0] = 'C';
$groups[2][0][1] = 'D';
$groups[2][1][0] = 'D';
$groups[2][1][1] = 'C';

$winner[1][0] = 1;
$winner[1][1] = 2;
$winner[2][0] = 3;
$winner[2][1] = 4;

$match_offset = 28; // 28 = sista matchen i kvartarna (28 + 1 = f�rsta semin)

for($match = 1; $match<=2; $match++) {

	/**
	hamtahemma = (f�rsta iterationen) alla lag som ligger i grupp A eller grupp B
	hamtaborta = (f�rsta iterationen) alla lag som ligger i grupp C eller grupp D
	*/
	$hamtahemma = mysql_query("SELECT * FROM lag WHERE lag LIKE '".$groups[$match][0][0]."%' OR lag LIKE '".$groups[$match][0][1]."%' ORDER BY lag;");
	$hamtaborta = mysql_query("SELECT * FROM lag WHERE lag LIKE '".$groups[$match][1][0]."%' OR lag LIKE '".$groups[$match][1][1]."%' ORDER BY lag;");
	
	$matchnumber = $match + $match_offset;
?>	
	<tr>
	<td colspan="7" align="center"><span class="rubrik4"><b>Semifinal <?=$match?></b></span><br><br></td>
	</tr>
	
	
<?	
	echo '<tr';
	// Anv�nds f�r att kolla om man "gl�mt" tippa p� n�n match, i s� fall skall hela den TR'n bli r�d. 
	//(err=true s�ger �t dig att n�got inte har tippats, anv�nds s�kert senare.....
	if(!empty($_SESSION['match']) && ($_SESSION['match'][$matchnumber][0] == '' || $_SESSION['match'][$matchnumber][1] == '' || $_SESSION['match'][$matchnumber][2] == '')) 
	{
		echo ' style="background-color: #FF0000;"';
		$err = true;
	}
	echo '><td align="center">'.($matchnumber).'</td>'.
			'<td><select style="width:100%;" name="match['.($matchnumber).'][1]">'.
			'<option value="">-- V�lj lag --';
			while($alag = mysql_fetch_array($hamtahemma,MYSQL_ASSOC)) {
				echo '<option value="'.$alag['lag'].'"';
				if($_SESSION['match'][$matchnumber][1] == $alag['lag']) // Detta kommer att anv�ndas om anv�ndaren redan tippat (dvs tippningen har sparats i sessionen)
					echo ' selected'; // ...isf s�tter vi den till selected
				echo '>'.$alag['land'];
			}
	echo	'</select>'.
			'</td>'.
			'<td align="center"> - </td>'.
			'<td><select style="width:100%;" name="match['.($matchnumber).'][2]">'.
			'<option value="">-- V�lj lag --';
			while($blag = mysql_fetch_array($hamtaborta,MYSQL_ASSOC)) {
				echo '<option value="'.$blag['lag'].'"';
				if($_SESSION['match'][$matchnumber][2] == $blag['lag'])
					echo ' selected';
				echo '>'.$blag['land'];
			}
	echo	'</select>'.
			'</td>'.		
			'<td align="center"><input type="radio" class=radio name="match['.($matchnumber).'][0]" value="1"';
	if($_SESSION['match'][$matchnumber][0] == '1') // anv�nds f�r att kolla med tippningen som ligger i sessionen om man tippat "etta"
		echo ' checked';
	echo '></td>'.
			'<td align="center"> - </td>'.
			'<td align="center"><input type="radio" class=radio name="match['.($matchnumber).'][0]" value="2"';
	if($_SESSION['match'][$matchnumber][0] == '2') // anv�nds f�r att kolla med tippningen som ligger i sessionen om man tippat "tv�"
		echo ' checked';
	echo '></td>'.
			'</tr>';
	echo '<tr><td></td><td>Vinnare kvartsfinal '.$winner[$match][0].'</td><td></td><td>Vinnare kvartsfinal '.$winner[$match][1].'</td></tr>';	
	echo '<tr><td colspan=7 align=center><hr align=center style="width:96%; height:1px;" color="#6C261F"></td></tr>';	

}

echo '</table><br><br><br>';


// -------------------------------------------------------- SEMI SLUT ----------------------------

// ------------------------ FINAL -----------------------------------

echo '<h3>Final</h3>';
echo '<table border=0 cellspacing=0 cellpadding=2>';
echo '<tr class=rubrik><td align=right>Match</td><td width=150 align=center>Hemma</td><td>-</td><td width=150 align=center>Borta</td><td align=center>1</td><td align=center>-</td><td align=center>2</td></tr>';


		$hamtahemma = mysql_query("SELECT * FROM lag WHERE id <= '8' '%' ORDER BY lag;");
		$hamtaborta = mysql_query("SELECT * FROM lag WHERE id >= '9' && id <= '16' '%' ORDER BY lag;");

$matchfinal = 31;

echo '<tr';
if(!empty($_SESSION['match']) && ($_SESSION['match'][$matchfinal][0]=='' || $_SESSION['match'][$matchfinal][1]=='' || $_SESSION['match'][$matchfinal][2]=='')) {
	echo ' style="background-color: #FF0000;"';
	$err = true;	
}
echo '><td align="center">'.$matchfinal.'</td>'.
		'<td><select style="width:100%;" name="match['.$matchfinal.'][1]">'.
		'<option value="">-- V�lj lag --';
		while($alag = mysql_fetch_array($hamtahemma,MYSQL_ASSOC)) {
			echo '<option value="'.$alag['lag'].'"';
			if($_SESSION['match'][$matchfinal][1] == $alag['lag'])
				echo ' selected';
			echo '>'.$alag['land'];
		}
echo	'</select>'.
		'</td>'.
		'<td align="center"> - </td>'.
		'<td><select style="width:100%;" name="match['.$matchfinal.'][2]">'.
		'<option value="">-- V�lj lag --';
		while($blag = mysql_fetch_array($hamtaborta,MYSQL_ASSOC)) {
			echo '<option value="'.$blag['lag'].'"';
			if($_SESSION['match'][$matchfinal][2] == $blag['lag'])
				echo ' selected';
			echo '>'.$blag['land'];
		}
echo	'</select>'.
		'</td>'.		
		'<td align="center"><input type="radio" class=radio name="match[31][0]" value="1"';
		if($_SESSION['match'][$matchfinal][0] == '1')
			echo ' checked';
		echo '></td>'.
		'<td align="center"> - </td>'.
		'<td align="center"><input type="radio" class=radio name="match[31][0]" value="2"';
		if($_SESSION['match'][$matchfinal][0] == '2')
			echo ' checked';
		echo '></td>'.
		'</tr>';
echo '<tr><td></td><td>Vinnare semifinal 1</td><td></td><td>Vinnare semifinal 2</td></tr>';	
echo '<tr><td colspan=7 align=center><hr align=center style="width:96%; height:1px;" color="#6C261F"></td></tr>';	

echo '</table><br><br><br>';

// ------------------------ FINAL ----------------------------------- SLUT

// ------------------------ Extra Fr�gor ----------------------------------- START
	
		$hamtahemma = mysql_query("SELECT * FROM lag WHERE id <= '16' '%' ORDER BY ID;");
		$hamtaborta = mysql_query("SELECT * FROM lag WHERE id <= '16' '%'ORDER BY ID;");
?>	
	<table border=0 cellspacing=0 cellpadding=2>
	<tr>
		<td colspan=4 align="center"><span class="rubrik4"><b>Extra Fr�gorna</b><br><br></span></td>
	</tr>
	<tr
<?	
	// Fr�ga - Vilket lag vinner EM2008? - START

		if(!empty($_SESSION['match']) && $_SESSION['match'][32] == '') {
			echo ' style="background-color: #FF0000;"';
			$err = true;	
		}
?>		
	>
		<td width=30 align="center">1</td>
		<td width=200>Vilket lag vinner EM2008?</td>
		<td align="center"></td>
		<td width=165>
			<select style="width:100%;" name="match[32]">
			<option value="">-- V�lj lag --
<?			
			while($blag = mysql_fetch_array($hamtaborta,MYSQL_ASSOC)) {
			echo '<option value="'.$blag['lag'].'"';
			if($_SESSION['match'][32] == $blag['lag']) 
				echo ' selected';
			echo '>'.$blag['land'];
			}
?>		
			</select>
		</td>
	</tr>		
	<tr>
		<td height=20 align="center"></td>
	</tr>
	<tr
<?
	// Fr�ga - Vilket lag vinner EM2008? - SLUT

	// Fr�ga - Hur m�nga m�l g�r Sverige? - START
	
		if(!empty($_SESSION['match']) && $_SESSION['match'][33] == '') {
			echo ' style="background-color: #FF0000;"';
			$err = true;	
		}
?>
	>
		<td align="center">2</td>
		<td>Hur m�nga m�l g�r Sverige?</td>
		<td></td>
		<td><input type="text" name="match[33]" size="3" maxlength="3" value="<?=$_SESSION['match'][33]?>"> st</td>
	</tr>	
	<tr>
		<td height=20 align="center"></td>
	</tr>	
	<tr
<?
	// Fr�ga - Hur m�nga m�l g�r Sverige? - SLUT

	// Fr�ga - Den spelare som g�r flest m�l heter? - START

		if(!empty($_SESSION['match']) && $_SESSION['match'][34][0] == '') {
			echo ' style="background-color: #FF0000;"';
			$err = true;	
		}
?>
	>
		<td align="center">3</td>
		<td>Den spelare som g�r flest m�l heter</td>
		<td></td>
		<td><input type="text" name="match[34][0]" size="30" maxlength="30" value="<?=$_SESSION['match'][34][0]?>"></td>
	</tr>
	<tr
<?
		if(!empty($_SESSION['match']) && $_SESSION['match'][34][1] == '') {
			echo ' style="background-color: #FF0000;"';
			$err = true;	
		}
?>
	>
		<td></td>
		<td>och spelar f�r landet</td>
		<td align="center"></td>
		<td width=165>
			<select style="width:100%;" name="match[34][1]">
			<option value="">-- V�lj lag --
<?
			while($alag = mysql_fetch_array($hamtahemma,MYSQL_ASSOC)) {
			echo '<option value="'.$alag['lag'].'"';
			if($_SESSION['match'][34][1] == $alag['lag'])
				echo ' selected';
			echo '>'.$alag['land'];
		}
?>
			</select>
		</td>
	</tr>			
	<tr>
		<td height=20></td>
	</tr>
<?
// ------------------------ Extra Fr�gor ----------------------------------- SLUT
		
if($err) {
	echo '<tr><td colspan=7 align="center"><span style="color: #FF0000; font-size: 14px; font-weight: bold;">DU HAR GL�MT ATT FYLLA I N�GOT!</span></td></tr>';	
}
?>
	<tr>
		<td colspan=7 align="center"><hr align="center" style="width:96%; height:1px;" color="#6C261F"></td>
	</tr>
	<tr>
		<td colspan=7 align="right"><input type="button" class="btn" value="Skicka tippning!" onClick="this.form.action='index.php?sida=tippning'; this.form.submit();"></td>
	</tr>


</td>
</tr>
</table>


<?
}

} else {// IF DATE IS OUT OF DATE
	echo '<table BGCOLOR="#FFFFFF" border="0" width="100%" height="100%">';
	echo '<tr>';
	echo '<td align="center">';
	
	echo '<center><h3><b>Permission denied!</b></h3><br>Du uppfyller inte kraven f�r att f� tippa, du kanske inte har betalt?<br></center>';
//	echo 'Sista datumet f�r tippningen ('$last_date ' ) kanske redan har passerat';
   
	echo '</td>';
	echo '</tr>';
	echo '</table>';
   }
?>
