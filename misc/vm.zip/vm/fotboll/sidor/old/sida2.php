<table BGCOLOR="#FFFFFF" border="0" width="100%" height="100%">
<tr>
<td align="center">

<? 

$grundspel = Array('A','B','C','D'/*,'E','F','G','H'*/);
// $eights = mysql_query("SELECT * FROM matcher WHERE ID >= '49' AND ID <= '56' ORDER BY ID ASC;");
$kvarts = mysql_query("SELECT * FROM matcher WHERE ID >= '25' AND ID <= '28' ORDER BY ID ASC;");
$semis = mysql_query("SELECT * FROM matcher WHERE ID >= '29' AND ID <= '30' ORDER BY ID ASC;");
?>



<span class=rubrik><br>Matcher<br></span><br>
<?
//---------------------------------------------------------- GRUNDSPELSMATCHERNA ----------------------------------------------------
?>
<span class=rubrik>Gruppspelsmatcher<br></span>

<table border=1 cellspacing=0 cellpadding=2>
<tr class=rubrik><td align=right>Match</td><td align=right>Hemma</td><td>-</td><td align=left>Borta</td><td>Datum</td><td>Klockan</td></tr>
<?
foreach($grundspel AS $grupp) {
	$matcher = mysql_query("SELECT * FROM matcher WHERE hemma LIKE '".$grupp."%' AND borta LIKE '".$grupp."%' ORDER BY ID ASC;");
?>	
		<tr><td colspan=6><span class=rubrik2>Grupp<?'.$grupp.';?></span></td></tr>
		<?
		while($match = mysql_fetch_array($matcher)) {
		$hemma = mysql_fetch_array(mysql_query("SELECT * FROM lag WHERE ID = '".$match['hemma']."';"), MYSQL_ASSOC);
		$borta = mysql_fetch_array(mysql_query("SELECT * FROM lag WHERE ID = '".$match['borta']."';"), MYSQL_ASSOC);
		?>
			<tr>
			<td align=right><?$match['id']?></td>
			<td align=right><?$hemma['land'] ?><img src="./pic/flaggor/<?$hemma['flagga']?>"></td>
			<td align=center> - </td>
			<td align=left><img src="./pic/flaggor/<?$borta['flagga']?>"><? $borta['land']?></td>
			<td align=left><?$match['datum']?></td>
			<td align=left><?$match['tid'];?></td>
			</tr>
	<?		
	}
	?>
	<tr><td colspan=6 align=center><hr align=center style="width:96%; height:1px;" color="#51AB4B"></td></tr>
<?	
}
?>
</table><br>

<?
//---------------------------------------------------------- GRUNDSPELSMATCHERNA SLUT ----------------------------------------------------

//---------------------------------------------------------- KVARTSFINALERNA ----------------------------------------------------


$tid = mysql_fetch_array(mysql_query("SELECT * FROM matcher WHERE ID = '5';"), MYSQL_ASSOC);
$datum = mysql_fetch_array(mysql_query("SELECT * FROM matcher WHERE ID = '5';"), MYSQL_ASSOC);
?>




<span class=rubrik>Kvartsfinaler<br></span>
<table border=1 cellspacing=0 cellpadding=4>
<tr class=rubrik><td align=right>Match</td><td align=right>Hemma</td><td>-</td><td align=left>Borta</td><td>Datum</td><td>Klockan</td></tr>
<td align=left><?$datum['datum'];?></td><td align=left><?$tid['tid'];?></td>

<?
//---------------------------------------------------------- KVARTSFINALERNA SLUT ----------------------------------------------------
?>
</td>
</tr>
</table>
