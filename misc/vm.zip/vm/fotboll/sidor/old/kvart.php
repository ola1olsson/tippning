<?
include 'config.php';
include 'connect_database.php';

?>

<html>
<body>
<h1>Kvarts</h1>

<form method="POST" action="kvart.php">
<?
// ------------------------ kvarts -----------------------------------

echo '<table border=0 cellspacing=0 cellpadding=2>';
echo '<tr class=rubrik><td align=right>Match</td><td width=150 align=center>Hemma</td><td>-</td><td width=150 align=center>Borta</td><td align=center>1</td><td align=center>-</td><td align=center>2</td></tr>';
/**
	groups f�rklaring:
	groups[i] -> i = gruppnummer
	groups[i][k] -> k(0) = hemma, k(1) = borta
*/

$groups[1][0] = 'A';
$groups[1][1] = 'B';
$groups[2][0] = 'C';
$groups[2][1] = 'D';
$groups[3][0] = 'B';
$groups[3][1] = 'A';
$groups[4][0] = 'D';
$groups[4][1] = 'C';

$match_offset = 24; // sista matchnumret i gruppspelet
$err = false;
for($match=1; $match<=sizeof($groups); $match++) {
	$hamtahemma = mysql_query("SELECT * FROM lag WHERE lag LIKE '".$groups[$match][0]."%';");
	$hamtaborta = mysql_query("SELECT * FROM lag WHERE lag LIKE '".$groups[$match][1]."%';");
	
	$matchnumber = $match + $match_offset;
	
	echo '<tr><td colspan=7><span class=rubrik2>Kvartsfinal '.$match.'</span></td></tr>';
	
	
	echo '<tr';
	// kollar s� att just denna match blivit tippad, annars f�rgar vi hela TR'n r�������d
	if(!empty($_SESSION['match']) && ($_SESSION['match'][$matchnumber][0] == '' || $_SESSION['match'][$matchnumber][1] == '' || $_SESSION['match'][$matchnumber][2] == '')) {
		echo ' style="background-color: #FF0000;"';
		$err = true;
	}
	echo '><td align=right>'.$matchnumber.'</td>'.
			'<td><select style="width:100%;" name="match['.$matchnumber.'][1]">'.
			'<option value="">-- V�lj lag --';
			while($alag = mysql_fetch_array($hamtahemma,MYSQL_ASSOC)) {
				echo '<option value="'.$alag['lag'].'"'; // h�r kan du anv�nda ID ist�llet om du vill, s� l�nge du anv�nder samma attribut som n�r du skall spara det i databasen
				if($_SESSION['match'][$matchnumber][1] == $alag['lag']) 
					echo ' selected';
				echo '>'.$alag['land'];
			}
	echo	'</select>'.
			'</td>'.
			'<td align=center> - </td>'.
			'<td><select style="width:100%;" name="match['.$matchnumber.'][2]">'.
			'<option value="">-- V�lj lag --';
			while($blag = mysql_fetch_array($hamtaborta,MYSQL_ASSOC)) {
				echo '<option value="'.$blag['lag'].'"';
				if($_SESSION['match'][$matchnumber][2] == $blag['lag']) 
					echo ' selected';
				echo '>'.$blag['land'];
			}
	echo	'</select>'.
			'</td>'.
			'<td align=center><input type="radio" class=radio name="match['.$matchnumber.'][0]" value="1"';
			
	// kolla om matchen redan �r tippad (och isf sparad i sessionen), i s� fall skall r�tt tippningen "checkas"
	if($_SESSION['match'][$matchnumber][0] == '1') echo ' checked';		
	
	echo 	'></td>'.
			'<td align=center> - </td>'.
			'<td align=center><input type="radio" class=radio name="match['.$matchnumber.'][0]" value="2"';
	if($_SESSION['match'][$matchnumber][0] == '2') echo ' checked';				
	echo 	'></td>'.
			'</tr>';
	echo '<tr><td></td><td>Vinnare grupp '.$groups[$match][0].'</td><td></td><td>Andraplats grupp '.$groups[$match][1].'</td></tr>';	
	echo '<tr><td colspan=7 align=center><hr align=center style="width:96%; height:1px;" color="#51AB4B"></td></tr>';	

}

echo '</table><br><br><br>';

echo 'Error? ';
if($err) 	echo 'true'; 
// om err=true s� f�r man inte skicka in sin tippning (dvs felmeddelande om att man 
//m�ste tippa p� allt innan man skickar in den). MEN man skall kunna spara det i databasen 
//och tippa vidare n�gon annan dag. s� n�r err=false (dvs allt �r tippat, s� skall en "flagga" 
//s�ttas p� anv�ndaren som s�ger att han/hon har en giltig tippning registrerad. Om anv�ndaren 
//sen g�r in och plockar v�ck en tipp :) s� skall flaggan s�ttas till false igen.
else 		echo 'false';
echo '<br/>';
?>
<input type="submit" value="Skicka skr�pet">
</form>
</body>
</html>