<table BGCOLOR="#FFFFFF" border="0" width="100%" height="100%">
<tr>
<td align="center" valign="top">
<br>
<span class="rubrik">Deltagare</span>
<br>
<br>

<?php

// Includerar uppkopling till MySQL-server.

include "config.php";
include "connect_database.php";

// h�r kan du ange den kod utf�r de �vriga uppgifterna nu n�r anslutningen �r gjord

// h�mtar information fr�n den angivna tabellen
$result = mysql_query("SELECT * FROM deltagare") or die(mysql_error());


// HTML-tabellens formatering - tabellstart
?>
	<table border="1" frame="below" bordercolor="#cb2725" cellspacing="0" cellpadding="5">
		<tr bgcolor="#cb2725" align="center">
			
			<td><b>Foto</b></td>
			<td><b>Anv�ndarnamn</b></td>
			<td><b>Namn</b></td>
			<td><b>Ort</b></td>
			<td><b>F�retag</b></td>
			<td><b>ID</b></td>
			
		</tr>
<?
// h�mtar resultatrader fr�n tabellen
while($row = mysql_fetch_array( $result ))
     { 
     // skriver ut inneh�llet i raderna till HTML-tabellen
?>	 
		<tr align="center">
			<td><img src="./pic/users/<?=$row['foto'];?>" width="50" height="50"></td>
			
			<td width="100"><?=$row['user'];?></td>
			<td width="150"><?=$row['fornamn'];?> &nbsp; <?=$row['efternamn'];?></td>
			<td width="75"><?=$row['ort'];?></td>
			<td width="100"><?=$row['foretag'];?></td>
			<td><?=$row['id'];?></td>
		</tr>	
<?		
     }
// HTML-tabellens formatering - tabellslut
?>
</table>


-----------------TEST----------------------
<table border="0">

<?
// h�mtar information fr�n den angivna tabellen
$result = mysql_query("SELECT * FROM deltagare") or die(mysql_error());

// h�mtar resultatrader fr�n tabellen
while($row = mysql_fetch_array( $result ))
     { 
     // skriver ut inneh�llet i raderna till HTML-tabellen
?>	 
		<tr align="left">
		<td>
			<a href="index.php?sida=deltagare&user=<?=$row['user'];?>">
			<table border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td width="250" colspan="3">
				<div class="roundtop">
				<div class="r1"></div>
				<div class="r2"></div>
				<div class="r3"></div>
				<div class="r4"></div>
				<div class="r5"></div>
				</div>
				</td>
			</tr>
			
			<tr bgcolor="#cb2725" align="left">
				<td width="5">
				</td>
				
				<td width="55" height="50">
				<img src="./pic/users/<?=$row['foto'];?>" width="50" height="50">
				</td>
			
				<td width="175">
				<b><?=$row['user'];?></b><br>
				<?=$row['fornamn'], '&nbsp;', $row['efternamn'];?><br>
				<?=$row['ort'];?><br>
				<?=$row['foretag'];?> &nbsp;&nbsp; <?=$row['id'];?>
				</td>
				
			</tr>
			<tr>
				<td colspan="3">
				<div class="roundbottom">
				<div class="r5"></div>
				<div class="r4"></div>
				<div class="r3"></div>
				<div class="r2"></div>
				<div class="r1"></div>
				</div>
				</td>
			</tr>
			</table>
			</a>
			
			</td>
		</tr>	
<?		
     }
// HTML-tabellens formatering - tabellslut
?>
</table>

-----------------TEST----------------------


<?
// st�nger databasen
mysql_close($opendb);

?>

</td>
</tr>
</table>
