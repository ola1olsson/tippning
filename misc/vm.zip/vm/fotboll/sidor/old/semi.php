<?
include 'config.php';
include 'connect_database.php';
?>

<html>

<body>
<?php

echo '<h1>SEMMMMMI!</h1>';
echo '<table border=0 cellspacing=0 cellpadding=2>';
echo '<tr class=rubrik><td align=right>Match</td><td width=150 align=center>Hemma</td><td>-</td><td width=150 align=center>Borta</td><td align=center>1</td><td align=center>-</td><td align=center>2</td></tr>';
// OPTIMERADE KVARTAR

$groups[1][0][0] = 'A';
$groups[1][0][1] = 'B';
$groups[1][1][0] = 'C';
$groups[1][1][1] = 'D';
$groups[2][0][0] = 'B';
$groups[2][0][1] = 'A';
$groups[2][1][0] = 'D';
$groups[2][1][1] = 'C';

$winner[1][0] = 1;
$winner[1][1] = 2;
$winner[2][0] = 3;
$winner[2][1] = 4;

$match_offset = 28; // 28 = sista matchen i kvartarna (28 + 1 = f�rsta semin)

for($match = 1; $match<=sizeof($groups); $match++) {

	/**
	hamtahemma = (f�rsta iterationen) alla lag som ligger i grupp A eller grupp B
	hamtaborta = (f�rsta iterationen) alla lag som ligger i grupp C eller grupp D
	*/
	$hamtahemma = mysql_query("SELECT * FROM lag WHERE lag LIKE '".$groups[$match][0][0]."%' OR lag LIKE '".$groups[$match][0][1]."%' ORDER BY lag;");
	$hamtaborta = mysql_query("SELECT * FROM lag WHERE lag LIKE '".$groups[$match][1][0]."%' OR lag LIKE '".$groups[$match][1][1]."%' ORDER BY lag;");
	
	$matchnumber = $match + $match_offset;
	
	echo '<tr><td colspan=7><span class=rubrik2>Kvartsfinal '.$match.'</span></td></tr>';
	
	
	
	echo '<tr';
	// Anv�nds f�r att kolla om man "gl�mt" tippa p� n�n match, i s� fall skall hela den TR'n bli r�d. 
	//(err=true s�ger �t dig att n�got inte har tippats, anv�nds s�kert senare.....
	if(!empty($_SESSION['match']) && ($_SESSION['match'][$matchnumber][0] == '' || $_SESSION['match'][$matchnumber][1] == '' || $_SESSION['match'][$matchnumber][2] == '')) 
	{
		echo ' style="background-color: #FF0000;"';
		$err = true;
	}
	echo '><td align=right>'.($matchnumber).'</td>'.
			'<td><select style="width:100%;" name="match['.($matchnumber).'][1]">'.
			'<option value="">-- V�lj lag --';
			while($alag = mysql_fetch_array($hamtahemma,MYSQL_ASSOC)) {
				echo '<option value="'.$alag['lag'].'"';
				if($_SESSION['match'][$matchnumber][1] == $alag['lag']) // Detta kommer att anv�ndas om anv�ndaren redan tippat (dvs tippningen har sparats i sessionen)
					echo ' selected'; // ...isf s�tter vi den till selected
				echo '>'.$alag['land'];
			}
	echo	'</select>'.
			'</td>'.
			'<td align=center> - </td>'.
			'<td><select style="width:100%;" name="match['.($matchnumber).'][2]">'.
			'<option value="">-- V�lj lag --';
			while($blag = mysql_fetch_array($hamtaborta,MYSQL_ASSOC)) {
				echo '<option value="'.$blag['lag'].'"';
				if($_SESSION['match'][$matchnumber][2] == $blag['lag'])
					echo ' selected';
				echo '>'.$blag['land'];
			}
	echo	'</select>'.
			'</td>'.		
			'<td align=center><input type="radio" class=radio name="match['.($matchnumber).'][0]" value="1"';
	if($_SESSION['match'][$matchnumber][0] == '1') // anv�nds f�r att kolla med tippningen som ligger i sessionen om man tippat "etta"
		echo ' checked';
	echo '></td>'.
			'<td align=center> - </td>'.
			'<td align=center><input type="radio" class=radio name="match['.($matchnumber).'][0]" value="2"';
	if($_SESSION['match'][$matchnumber][0] == '2') // anv�nds f�r att kolla med tippningen som ligger i sessionen om man tippat "tv�"
		echo ' checked';
	echo '></td>'.
			'</tr>';
	echo '<tr><td></td><td>Vinnare �ttondelsfinal '.$winner[$match][0].'</td><td></td><td>Vinnare �ttondelsfinal '.$winner[$match][1].'</td></tr>';	
	echo '<tr><td colspan=7 align=center><hr align=center style="width:96%; height:1px;" color="#51AB4B"></td></tr>';	

}

echo '</table><br><br><br>';


?>


</body>
</html>