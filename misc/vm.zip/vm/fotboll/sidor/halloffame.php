
<?
//if(date('Y-m-d')>='2006-06-09' && date('H.i')>'20.00') {
	echo '<center><span class="rubrik2">Hall of fame<br></span><br>';
	echo '<span class="rubrik3">10-i-Topp<br></span></center><br>
		<table border=0 cellspacing=0 cellpadding=1 style="width:100%;">';
	$top10 = mysql_query("SELECT id, fornamn, efternamn, points FROM deltagare ORDER BY points DESC, fornamn ASC;");
	$placering = 1;
	$points = -1;
	for($i=1; $i<=10; $i++) {
		$usr = mysql_fetch_array($top10, MYSQL_ASSOC);
		if($points != $usr['points'] && $points != -1)
			$placering++;
		$points = $usr['points'];
		echo '<tr><td align=right>'.$placering.'.</td>'.
				'<td style="width:100%;"><a href="index.php?sida=visadeltagare&id='.$usr['id'].'">'.$usr['fornamn'].' '.$usr['efternamn']{0}.'</a></td>'.
				'<td align=right>'.$usr['points'].'p</td></tr>';

	}
	echo '</table><br>';
//}
//<hr align=center style="width:96%; height:1px;" color="#51AB4B">

?>