<?
if(session_is_registered('permission') && $_SESSION['permission'] && $_SESSION['betalt'] == 1 && (date('Y-m-d')>$last_bet_day || $_SESSION['admin'])) {
?>

<table BGCOLOR="#FFFFFF" width="100%" height="100%"  bordercolor="#6C261F"  cellpadding="30" cellspacing="0">
<tr>
<td align="left" valign="top" frame="rhs" border="1"> 

<span class="rubrik">J�mf�r<br></span><br>

<?
$grundspel_max = 24;
$slutspel_max = 31;

//echo '<div style="width: 100%; height: 100%; background-color: white;" align="center">';
// <div style="width: 100%; height: 100%; left: 0px; top: 0px; position: absolute; z-index: 0;"></div> -->
if(isset($_POST['check'])) {
	if($_REQUEST['cmd'] == 'allusers') {
	$allusers = mysql_query("SELECT tippning.id FROM deltagare, tippning WHERE deltagare.id != '".$_SESSION['userID']."' AND deltagare.id = tippning.id ORDER BY fornamn ASC;") or die(mysql_error());
	$k_usr = 0;
	unset($_POST['users']);
	while($usr = mysql_fetch_array($allusers, MYSQL_ASSOC))
		$_POST['users'][$k_usr++] = $usr['id'];	
	} 
	echo '<a href="index.php?sida=resultat">Klicka h�r f�r att g�ra en ny j�mf�relse</a><br><br>';
	
	$users[0] = 0;
	$users[1] = $_SESSION['userID'];
	$i_user = 2;
	foreach($_POST['users'] as $user) {
		$users[$i_user] = $user;
		$i_user++;
	}
	// DATABASE CONNECTION ESTABLISHMENT
	$query = "SELECT * FROM tippning WHERE ";
	for($i=0; $i<sizeof($users); $i++) {
		$query .= "id = '".$users[$i]."' OR ";
	}
	$query .= "id = '".$users[sizeof($users)]."';";
	
	$db_result = mysql_query($query);
	while($db_res = mysql_fetch_array($db_result,MYSQL_ASSOC)) {
		for($i=1; $i<=$grundspel_max; $i++) {
			$result[$db_res['id']][$i] = $db_res['m'.$i];	
		}
		for($i=$grundspel_max + 1; $i<=$slutspel_max; $i++) {
			$result[$db_res['id']][$i][0] = $db_res['m'.$i];
			$result[$db_res['id']][$i][1] = $db_res['m'.$i.'a'];
			$result[$db_res['id']][$i][2] = $db_res['m'.$i.'b'];
		}
		$result[$db_res['id']][$slutspel_max + 1] = $db_res['m32a'];
		$result[$db_res['id']][$slutspel_max + 2] = $db_res['m33a'];
		$result[$db_res['id']][$slutspel_max + 3][0] = $db_res['m34a'];
		$result[$db_res['id']][$slutspel_max + 3][1] = $db_res['m34b'];
	}
	$rowspan = (4*7)+3;
	echo '<table border=0 bordercolor=black cellspacing=2 cellpadding=0>';
	
	echo '<tr>
			<td align=left valign=bottom colspan=4></td>
			<td align=center valign=bottom><span class=vertical>Resultat</span></td>';
	for($i=1; $i<sizeof($users); $i++) 
	{
		$user_name = mysql_fetch_array(mysql_query("SELECT fornamn, efternamn FROM deltagare WHERE id ='".$users[$i]."';"), MYSQL_ASSOC);
		echo '<td align=left valign=bottom><span class=vertical>'.$user_name['fornamn'].'<br>'.$user_name['efternamn'].'</span></td>';
		echo '<td style="width:1px;" bgcolor="#550000" rowspan='.$rowspan.'><img src="./pics/spacer.gif" style="width:1px;" border=0></td>';
	}
	echo '</tr>';
	echo '<tr style="font-weight:bold;">
			<td align=left valign=bottom colspan=5>Antal po�ng:</td>';
	for($i=1; $i<sizeof($users); $i++) 
	{
		$user_points = mysql_fetch_array(mysql_query("SELECT points FROM deltagare WHERE id ='".$users[$i]."';"), MYSQL_ASSOC);
		echo '<td align=center valign=bottom>'.$user_points['points'].'p</td>';
	}
	echo '</tr>';
	$colspans = 4+(sizeof($users)+1);
	
	// GRUPPSPEL
	echo '<tr><td colspan='.$colspans.' align=left><span class=rubrik4>Gruppspel</span></td></tr>';
	$grundspel = Array('a','b','c','d');
	foreach($grundspel AS $grupp) {
		$matcher = mysql_query("SELECT * FROM matcher WHERE hemma LIKE '".$grupp."%' AND borta LIKE '".$grupp."%' ORDER BY id ASC;");
		echo '<tr><td colspan='.$colspans.' align=left><span class=rubrik5>Grupp '.$grupp.'</span></td></tr>';
		
		while($match = mysql_fetch_array($matcher, MYSQL_ASSOC)) {
			$hemma = mysql_fetch_array(mysql_query("SELECT * FROM lag WHERE lag = '".$match['hemma']."';"),MYSQL_ASSOC);
			$borta = mysql_fetch_array(mysql_query("SELECT * FROM lag WHERE lag = '".$match['borta']."';"),MYSQL_ASSOC);
			echo '<tr><td align=left>'.$match['id'].'. </td><td align=center><img src="./pic/flaggor/'.$hemma['flagga'].'" alt="'.$hemma['land'].'"></td><td align=center> - </td><td align=center><img src="./pic/flaggor/'.$borta['flagga'].'" alt="'.$borta['land'].'">&nbsp;&nbsp;</td>';
			echo '<td align=center bgcolor="#AAFFAA">'.$result[0][$match['id']].'</td>';
			for($i=1; $i<sizeof($users); $i++) {
				echo '<td align=center style="background-color: ';
				if($result[0][$match['id']] != '') {
					if($result[$users[$i]][$match['id']] == $result[0][$match['id']])
						echo '#00FF00';
					else
						echo '#FFAAAA';
				} else {
					echo 'none';	
				}
				echo ';">'.$result[$users[$i]][$match['id']].'</td>';
			}
			echo '</tr>';	
		}
	}
	echo '</table><br><br>';

	// SLUTSPELET
	
	$rowspan = 2+sizeof($users);
	$teams_res = mysql_query("SELECT * FROM lag ORDER BY id ASC;");
	while($team_row = mysql_fetch_array($teams_res)) {
		$teams[$team_row['lag']]['land'] = substr($team_row['land'],0,3);
		$teams[$team_row['lag']]['flag'] = $team_row['flagga'];
	}
	
	echo '<span class=rubrik4>Slutspel<br></span>'.
		'<table border=0 cellspacing=2 cellpadding=0>'.
		'<tr><td><span class=rubrik4>Match</span></td>'.
		'<td style="width:1px;" bgcolor="#550000" rowspan='.$rowspan.'><img src="./pics/spacer.gif" style="width:1px;" border=0></td>';
	for($i=$grundspel_max + 1; $i<=$slutspel_max; $i++) {
		echo '<td colspan=4 align=center><span style="font-weight:bold;">'.$i.'</span></td>'.
			'<td style="width:1px;" bgcolor="#550000" rowspan='.$rowspan.'><img src="./pics/spacer.gif" style="width:1px;" border=0></td>';
	}
	echo '</tr>';
	
	echo '<tr bgcolor="#AAFFAA"><td><span class=rubrik5>Resultat</span></td>';
	for($i=$grundspel_max + 1; $i<=$slutspel_max; $i++) {
		echo '<td align=center>';
		if($result[0][$i][1] != '')
			echo '<img src="./pic/flaggor/'.$teams[$result[0][$i][1]]['flag'].'" border=0><br>'.$teams[$result[0][$i][1]]['land'];	
		else 
			echo '&nbsp';
		echo '</td><td align=center>&nbsp;-&nbsp;</td><td align=center>';
		if($result[0][$i][2] != '')
			echo '<img src="./pic/flaggor/'.$teams[$result[0][$i][2]]['flag'].'" border=0><br>'.$teams[$result[0][$i][2]]['land'];	
		echo '</td><td align=center><span style="font-size:18px;">';
		if($result[0][$i][0] != '')
			echo $result[0][$i][0];
		else
			echo '&nbsp;';
		echo '</span></td>';
	}
	echo '</tr>';
	for($k=1; $k<sizeof($users); $k++) {
		$user_name = mysql_fetch_array(mysql_query("SELECT fornamn, efternamn FROM deltagare WHERE id ='".$users[$k]."';"), MYSQL_ASSOC);
		
		echo 	'<tr>'.
				'<td align=left>'.$user_name['fornamn'].' '.$user_name['efternamn']{0}.'</td>';
		for($i=$grundspel_max + 1; $i<=$slutspel_max; $i++) {
			echo '<td align=center';
			if($result[0][$i][1] != '') {
				if($result[$users[$k]][$i][1] == $result[0][$i][1])
					echo ' bgcolor="#00FF00"';
				else
					echo ' bgcolor="#FFAAAA"';
			}
			echo '>'.
				'<img src="./pic/flaggor/'.$teams[$result[$users[$k]][$i][1]]['flag'].'" border=0><br>'.$teams[$result[$users[$k]][$i][1]]['land'].
				'</td><td align=center>&nbsp;-&nbsp;</td><td align=center';
			if($result[0][$i][2] != '') {
				if($result[$users[$k]][$i][2] == $result[0][$i][2])
					echo ' bgcolor="#00FF00"';
				else
					echo ' bgcolor="#FFAAAA"';
			}
			echo '>'.
				'<img src="./pic/flaggor/'.$teams[$result[$users[$k]][$i][2]]['flag'].'" border=0><br>'.$teams[$result[$users[$k]][$i][2]]['land'].
				'</td><td align=center';
			if($result[0][$i][0] != '') {
				if($result[$users[$k]][$i][0] == $result[0][$i][0])
					echo ' bgcolor="#00FF00"';
				else
					echo ' bgcolor="#FFAAAA"';
			}
			echo '><span style="font-size:18px;">'.$result[$users[$k]][$i][0].'</span></td>';
		}
		echo 	'</tr>';
	}
	
	echo '</table></div>';
		
		/**
		echo '<table border=0 bordercolor=black cellspacing=2 cellpadding=0>';
		
		echo '<tr><td colspan='.$colspans.' align=left><span class=rubrik2><br>�ttondelsfinaler</span></td></tr>';
		echo '<tr>
				<td align=left valign=bottom colspan=4></td>
				<td align=center valign=bottom><span class=vertical>Resultat</span></td>';
		for($i=1; $i<sizeof($users); $i++) {
			$user_name = mysql_fetch_array(mysql_query("SELECT fornamn, efternamn FROM deltagare WHERE ID ='".$users[$i]."';"), MYSQL_ASSOC);
			echo '<td align=left valign=bottom><span class=vertical>'.$user_name['fornamn'].'<br>'.$user_name['efternamn'].'</span></td>';
			echo '<td style="width:1px;" bgcolor="#550000" rowspan='.$rowspan.'><img src="./pics/spacer.gif" style="width:1px;" border=0></td>';
		}
		echo '</tr>';
		$colspans = 3+sizeof($users)*3;
		$teams_res = mysql_query("SELECT * FROM teams ORDER BY ID ASC;");
		while($team_row = mysql_fetch_array($teams_res)) {
			$teams[$team_row['ID']]['land'] = substr($team_row['land'],0,3);
			$teams[$team_row['ID']]['flag'] = $team_row['flagga'];	
		}
		
		for($i=49; $i<=56; $i++) {
			echo '<tr><td align=left rowspan=3>'.$i.'. </td>';
			echo '<td align=center>H</td>';
			echo '<td align=center>&nbsp;';
			if($result[-1][$i][1] != '')
				echo '<img src="./pic/flaggor/'.$teams[$result[-1][$i][1]]['flag'].'">';
			echo '&nbsp;</td>';
			for($k=1; $k<sizeof($users); $k++) {
				echo '<td align=center style="background-color: ';
				if($result[-1][$i][1]!='') {
					if($result[$users[$k]][$i][1] == $result[-1][$i][1])
						echo '#00FF00';
					else
						echo '#FF7777';
				} else 
					echo 'none';
				echo ';">&nbsp;<img src="./pic/flaggor/'.$teams[$result[$users[$k]][$i][1]]['flag'].'" border=0>&nbsp;</td>';
			}
			echo '</tr>';
			
			echo '<tr>'.
				'<td align=center>R</td>'.
				'<td align=center>&nbsp;';
			if($result[-1][$i][0] != '')
				echo $result[-1][$i][0];
			echo '&nbsp;</td>';
			for($k=1; $k<sizeof($users); $k++) {
				echo '<td align=center style="background-color: ';
				if($result[-1][$i][0]!='') {
					if($result[$users[$k]][$i][0] == $result[-1][$i][0])
						echo '#00FF00';
					else
						echo '#FF7777';
				} else 
					echo 'none';
				echo ';">'.$result[$users[$k]][$i][0].'</td>';
			}
			echo '</tr>';
			
			echo '<tr>'.
				'<td align=center>B</td>'.
				'<td align=center>&nbsp;';
			if($result[-1][$i][2] != '')
				echo '<img src="./pic/flaggor/'.$teams[$result[-1][$i][2]]['flag'].'">';
			echo '&nbsp;&nbsp;</td>';
			for($k=1; $k<sizeof($users); $k++) {
				echo '<td align=center style="background-color: ';
				if($result[-1][$i][2]!='') {
					if($result[$users[$k]][$i][2] == $result[-1][$i][2])
						echo '#00FF00';
					else
						echo '#FF7777';
				} else 
					echo 'none';
				echo ';">&nbsp;<img src="./pic/flaggor/'.$teams[$result[$users[$k]][$i][2]]['flag'].'" border=0>&nbsp;</td>';
			}
			echo '</tr>';
		}
		echo '</table>';
		*/
		
		
			
			/**
			echo '<td align=center> - </td><td align=center>';
			if($result[-1][$i][2] != '')
				echo '<img src="./pic/flaggor/'.$teams[$result[-1][$i][2]]['flag'].'">';
			echo '&nbsp;&nbsp;</td>';
			echo '<td align=center bgcolor="#AAFFAA">'.$result[-1][0].'</td>';
			for($k=1; $k<sizeof($users); $k++) {
				echo '<td align=center style="background-color: ';
				if($result[-1][$i][1]!='') {
					if($result[$users[$k]][$i][1] == $result[-1][$i][1])
						echo '#00FF00';
					else
						echo '#FF7777';
				} else 
					echo 'none';
				echo ';"><img src="./pic/flaggor/'.$teams[$result[$users[$k]][$i][1]]['flag'].'" border=0></td>';
				echo '<td align=center style="background-color: ';
				if($result[-1][$i][0]!='') {
					if($result[$users[$k]][$i][0] == $result[-1][$i][0])
						echo '#00FF00';
					else
						echo '#FF7777';
				} else
					echo 'none';
				echo ';">'.$result[$users[$k]][$i][0].'</td>';
				echo '<td align=center style="background-color: ';
				if($result[-1][$i][2]!='') {
					if($result[$users[$k]][$i][2] == $result[-1][$i][2])
						echo '#00FF00';
					else
						echo '#FF7777';
				} else 
					echo 'none';
				echo ';"><img src="./pic/flaggor/'.$teams[$result[$users[$k]][$i][2]]['flag'].'" border=0></td>';
			}
			echo '</tr>';*/	

	/**
	// KVARTSFINALER
	echo '<tr><td colspan='.$colspans.' align=left><span class=rubrik2><br>Kvartsfinaler</span></td></tr>';
	
	
	// SEMIFINALER
	echo '<tr><td colspan='.$colspans.' align=left><span class=rubrik2><br>Semifinaler</span></td></tr>';
	
	
	// FINAL
	echo '<tr><td colspan='.$colspans.' align=left><span class=rubrik2><br>Final</span></td></tr>';
	
	*/
	
} else {

	if(mysql_num_rows(mysql_query("SELECT id FROM tippning WHERE id = '".$_SESSION['userID']."';"))) {
		echo '<span class=rubrik4>Kryssa f�r de personer vilka Du vill j�mf�ra Ditt resultat med.<br></span>Obs! Endast de personer som har tippat visas i listan.<br><br>';
		echo '<input type=button class=btn value="J�mf�r alla" onClick="this.form.action=\'index.php?sida=resultat&cmd=allusers\'; this.form.submit();"><br><br>';
		echo '<input type=hidden name=check value=true>';
		$users = mysql_query("SELECT deltagare.id, deltagare.fornamn, deltagare.efternamn FROM deltagare, tippning WHERE deltagare.id != '".$_SESSION['userID']."' AND deltagare.id = tippning.id ORDER BY fornamn ASC;") or die(mysql_error());
		echo '<table border=0 cellspacing=0 cellpadding=2>';
		$i_user = 0;
		while($user = mysql_fetch_array($users, MYSQL_ASSOC)) {
			echo '<tr><td>'.$user['fornamn'].' '.$user['efternamn'].'</td><td><input type=checkbox name=users['.($i_users++).'] value="'.$user['id'].'"></td></tr>';
		}
		echo '</tr><tr><td colspan=2 align=right><input type=button class=btn value="J�mf�r!" onClick="this.form.action=\'index.php?sida=resultat\'; this.form.submit();"></td></tr></table>';
	} else {
		echo '<span class=rubrik2>Du m�ste tippa innan du kan j�mf�ra ditt resultat med n�gon annans.<br></span>';
	}
}
?>
</td>
</tr>
</table>
<?

} else
	echo 'Permission denied!';
	
	
?>