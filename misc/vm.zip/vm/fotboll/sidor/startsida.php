
<?
// Det h�r f�rsta �r bara en funktion som r�knar ut hur m�nga dagar det �r kvar till ett visst datum.
// Anv�nds p� startsidan f�r att r�kna ut hur m�nga dagar det �r till cupStart
function daysLeft() {
	$now = mktime();
	$cupStart = mktime(0,0,0,06,11,2010);
	return floor((($cupStart - $now)/3600)/24);	
    }
?>

<table BGCOLOR="#FFFFFF" width="100%" height="100%"  bordercolor="#6C261F"  cellpadding="0" cellspacing="0">
<tr>
<td align="center" frame="rhs" border="1"> 

<?
// om dagensdatum inte �r mer �n last_bet_day s� visas nedr�kningen
if(date('Y-m-d')<$last_bet_day)
		echo 'Det �r nu <span class=rubrik><span style="font-size: 50px; font-weight:bolder;">'.daysLeft().'</span> dagar kvar till vm b�rjar</span><br><br>';
?>
<span style="font-size: 20px; font-weight:bolder; color: #000000;">V�lkommen</span><br>

<h5><B>Sista datum f�r tippning<br>
<?=$last_bet_day?></b><br></h5>

<?

$potten = (mysql_result(mysql_query("SELECT COUNT(*) FROM users WHERE betalt = '1';"),0))*50;
?>
<span style="font-size: 11px; font-weight:bolder; color: #cb2725;">F�r tillf�llet �r det <b><?=$potten?>kr</B> i potten, vem kammar hem vinsten?!<br></span>



<br>
<table border=0 cellspacing=2 cellpadding=0 style="width:100%;">
<tr>

<?	
	// ------------------ N�STA MATCH -------------------------
$date = date('Y-m-d');
$time = date('H.i');
$nextGames = mysql_query("SELECT * FROM matcher WHERE datum >= '".$date."' ORDER BY datum ASC, tid ASC;");
$game = mysql_fetch_array($nextGames, MYSQL_ASSOC);
while($game['tid'] < $time && $game['datum']==$date) 
	$game = mysql_fetch_array($nextGames, MYSQL_ASSOC);
$hemma = mysql_fetch_array(mysql_query("SELECT * FROM lag WHERE lag = '".$game['hemma']."';"), MYSQL_ASSOC);
$borta = mysql_fetch_array(mysql_query("SELECT * FROM lag WHERE lag = '".$game['borta']."';"), MYSQL_ASSOC);
/*echo '<td valign=top align=center bgcolor=#D2F2CE onClick=\'document.location="default.php?page=odds&id='.$game['id'].'";\' onMouseOver=\'this.bgColor="#51AB4B"; this.style.cursor="hand";\' onMouseOut=\'this.bgColor="#D2F2CE"\'>
		<span class=rubrik2>N�sta match<br></span>';


if($game['tvkanal'] != '') {
	echo '<tr><td>TV-kanal:</td><td><img src="./pics/tv/'.$game['tvkanal'].'" border=0></td></tr>';
}
echo 	'</table>';


*/
$ods['1'] = 0;
$ods['X'] = 0;
$ods['2'] = 0;
$odsRes = mysql_query("SELECT m".$game['id']." FROM tippning WHERE m".$game['id']." != '' AND id != '0';");
$nbrUsrs = mysql_num_rows($odsRes);
while($tmp = mysql_fetch_array($odsRes, MYSQL_ASSOC)) {
	switch($tmp['m'.$game['id']]) {
		case '1': $ods['1']++; break;
		case 'X': $ods['X']++; break;
		case '2': $ods['2']++; break;
	}
}

?>
	<table width="500" cellspacing="1" cellpadding="0">
	<tr>
				<td colspan="2"><hr align="center" style="width:100%; height:2px;" color="#6C261F"></td>
	</tr>
	<tr>
				<td><b>N�STA MATCH</b></td>			
	</tr>
	<tr>	
		<td>
			<table border="0" cellspacing="0" cellpadding="2" width="250">
			
			<tr>
				<td></td>
				<td valign="center" align="right"><?=$hemma['land'] ?>&nbsp;<img src="./pic/flaggor/<?=$hemma['flagga']?>" align="absmiddle"></td>
				<td valign="center" align="center"> - </td>
				<td valign="center" align="left"><img src="./pic/flaggor/<?=$borta['flagga'] ?>" align="absmiddle">&nbsp;<?=$borta['land']?></td>
			</tr>
			<tr>
				<td></td>
				<td align="center" style="width:50%;"><b>1<br></b></td>
				<td align="center"><b>X<br></b></td>
				<td align="center" style="width:50%;"><b>2<br></b></td>
			</tr>
			<tr>
				<td align="right"><b>Odds:<br></b></td>
				<td align="center"><?=round(($ods['1']/$nbrUsrs*100),2)?>%</td>
				<td align="center"><?=round(($ods['X']/$nbrUsrs*100),2)?>%</td>
				<td align="center"><?=round(($ods['2']/$nbrUsrs*100),2)?>%</td>
			</table>
		</td>
		<td>	
			<table border="0" cellspacing="0" cellpadding="2">
			<tr>
				<td>Datum:</td>
				<td><?=$game['datum']?></td>
			</tr>
			<tr>
				<td>Tid:</td>
				<td><?=$game['tid']?></td>
			</tr>
			<tr>
				<td>Plats:</td>
				<td><?=$game['plats']?></td>
			</tr>
			<tr>
				<td>Matchnr:</td>
				<td><?=$game['id']?>		
				</td>
			</tr>	
			</table>
	
		</td>
	</tr>
	<tr>
		<td colspan="2"><hr align="center" style="width:100%; height:2px;" color="#6C261F"></td>
	</tr>
	</table>	
<?		
// ----------------------------------------------------------------
?>







<table>	
	<tr>
	<td>
		
<?		
// ------------------ N�STA SVERIGE-MATCH -------------------------
	
$date = date('Y-m-d');
$time = date('H.i');
$nextGames = mysql_query("SELECT * FROM matcher WHERE datum >= '".$date."' AND (hemma = 'd2' OR borta = 'd2') ORDER BY datum ASC, tid ASC;");
if($game = mysql_fetch_array($nextGames, MYSQL_ASSOC)) {
	while($game['tid'] < $time && $game['datum']==$date) 
		$game = mysql_fetch_array($nextGames, MYSQL_ASSOC);
	$hemma = mysql_fetch_array(mysql_query("SELECT * FROM lag WHERE lag = '".$game['hemma']."';"), MYSQL_ASSOC);
	$borta = mysql_fetch_array(mysql_query("SELECT * FROM lag WHERE lag = '".$game['borta']."';"), MYSQL_ASSOC);
//	echo <td valign=top align=center bgcolor=#D2F2CE onClick=\'document.location="default.php?page=odds&id='.$game['id'].'";\' onMouseOver=\'this.bgColor="#51AB4B"; this.style.cursor="hand";\' onMouseOut=\'this.bgColor="#D2F2CE"\'>
		//<span class=rubrik2>N�sta Sverige-match<br></span>
//	if($game['tvkanal'] != '') {
//		echo '<tr><td>TV-kanal:</td><td><img src="./pics/tv/'.$game['tvkanal'].'" border=0></td></tr>';
//	}

	echo 	'</table>';
	
	
	// ODDSEN I MATCHEN, borttaget f�r att anv�ndarna inte ska se vad andra spelare tippar innan tippningen �r avslutad.
	$ods['1'] = 0;
	$ods['X'] = 0;
	$ods['2'] = 0;
	$odsRes = mysql_query("SELECT m".$game['id']." FROM tippning WHERE m".$game['id']." != '' AND id != '0';");
	$nbrUsrs = mysql_num_rows($odsRes);
	while($tmp = mysql_fetch_array($odsRes, MYSQL_ASSOC)) {
		switch($tmp['m'.$game['id']]) {
			case '1': $ods['1']++; break;
			case 'X': $ods['X']++; break;
			case '2': $ods['2']++; break;
		}
	}
	
	//echo 	'<table border=0 cellspacing=0 cellpadding=2 style="width:100%;"><tr>
		//	<td align=center style="width:50%;"><b>1<br></b>'.round(($ods['1']/$nbrUsrs*100),2).'%</td>
			//<td align=center><b>X<br></b>'.round(($ods['X']/$nbrUsrs*100),2).'%</td>
			//<td align=center style="width:50%;"><b>2<br></b>'.round(($ods['2']/$nbrUsrs*100),2).'%</td>
			//</tr></table><br>';
	
?>
	<table width="500" cellspacing="1" cellpadding="0">
	<tr>
				<td colspan="2"><hr align="center" style="width:100%; height:2px;" color="#6C261F"></td>
	</tr>
	<tr>
				<td><b>N�STA SVERIGE MATCH</b></td>			
	</tr>
	<tr>	
		<td>
			<table border="0" cellspacing="0" cellpadding="2" width="250">
			
			<tr>
				<td></td>
				<td valign="center" align="right"><?=$hemma['land'] ?>&nbsp;<img src="./pic/flaggor/<?=$hemma['flagga']?>" align="absmiddle"></td>
				<td valign="center" align="center"> - </td>
				<td valign="center" align="left"><img src="./pic/flaggor/<?=$borta['flagga'] ?>" align="absmiddle">&nbsp;<?=$borta['land']?></td>
			</tr>
			<tr>
				<td></td>
				<td align="center" style="width:50%;"><b>1<br></b></td>
				<td align="center"><b>X<br></b></td>
				<td align="center" style="width:50%;"><b>2<br></b></td>
			</tr>
			<tr>
				<td align="right"><b>Odds:<br></b></td>
				<td align="center"><?=round(($ods['1']/$nbrUsrs*100),2)?>%</td>
				<td align="center"><?=round(($ods['X']/$nbrUsrs*100),2)?>%</td>
				<td align="center"><?=round(($ods['2']/$nbrUsrs*100),2)?>%</td>
			</table>
		</td>
		<td>	
			<table border="0" cellspacing="0" cellpadding="2">
			<tr>
				<td>Datum:</td>
				<td><?=$game['datum']?></td>
			</tr>
			<tr>
				<td>Tid:</td>
				<td><?=$game['tid']?></td>
			</tr>
			<tr>
				<td>Plats:</td>
				<td><?=$game['plats']?></td>
			</tr>
			<tr>
				<td>Matchnr:</td>
				<td><?=$game['id']?>
			
<?			
} else {
	//echo '<td valign=top align=center bgcolor=#D2F2CE><span class=rubrik2>Ingen Sverige-match hittad</span>';
}
// ------------------ N�STA SVERIGE-MATCH SLUT -------------------------
?>		
				</td>
			</tr>	
			</table>
	
		</td>
	</tr>
	<tr>
		<td colspan="2"><hr align="center" style="width:100%; height:2px;" color="#6C261F"></td>
	</tr>
	</table>


<br>
<br>
	<table border="0">
		<tr>
			<td cellpadding="20" cellspacing="20">
			<b>Tidigare �rs vinnare av fotbolls EM</b><br>
			<br>
			2004: Grekland<br>
			2000: Frankrike (2)<br>
			1996: Tyskland (3)<br>
			1992: Danmark<br>
			1988: Holland<br>
			1984: Frankrike<br>
			1980: V�sttyskland (2)<br>
			1976: Tjekoslovakien<br>
			1972: V�sttyskland<br>
			1968: Italien<br>
			1964: Spanien<br>
			1960: Sovjet<br>
			<br>	
			</td>
		</tr>
	</table>
<br>
	<table border="0">
		<tr>
			<td cellpadding="20" cellspacing="20">
			<b>Tidigare �rs vinnare av Tippningen EM & VM</b><br>
			<br>
			VM2006: Karin Waldemarsson, Vinstsumma 1800:-<br>
			EM2004: Lennart Karlsson, Vinstsumma 650:-<br>
			
			<br>	
			</td>
		</tr>
	</table>

