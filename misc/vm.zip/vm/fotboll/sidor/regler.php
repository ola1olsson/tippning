<?
if(session_is_registered('permission') && $_SESSION['permission']) {
?>

<table BGCOLOR="#FFFFFF" width="100%" height="100%"  bordercolor="#6C261F"  cellpadding="30" cellspacing="0">
<tr>
<td align="left" valign="top" frame="rhs" border="1"> 


<center><span class="rubrik">Regler</span></center>
<BR>
<B>Allm�nt</B><BR>
Detta �r en privat tippning f�r ett slutet s�llskap.<BR>
Du, som deltagare inte f�r bjuda in andra till sidan.<BR>
Inbjudan g�ller endast dig, eftersom du �r s� speciell.<BR>
Deltaga kostar <?=$price?> SEK<BR>
Du m�ste ha tippat <u>senast</u> <?=$last_bet_day?><BR>
Skulle n�gon match bli inst�lld kommer den inte att ge n�gra po�ng.<BR>
Din tippning beh�ver inte st�mma hela v�gen igenom.<BR>
Dvs att om du i gruppspelet f�r ett lag som vinnare via resultat beh�ver du inte s�tta detta lag som vinnare f�r gruppen.<BR>
<BR>
<B>Resultat</B><BR>
I gruppspelet g�ller resultaten 1 X 2<BR>
I slutspelet g�ller 1 2, eftersom ett lag m�ste vinna.<BR>
Skulle lagen vara skiftade, dvs hemma och bortalag, f�r du inget po�ng.<BR>
<BR>
<B>Vinst</B><BR>
Beroende p� hur m�nga som �r med s� best�mmer jag hur summan ska f�rdelas<BR>
F�rmodligen delas den p� minst 1 och max 3 stycken.<BR>

<BR>
<B>Forum</B><BR>
Forumet �r till f�r deltagarna att kommunicera med varandra och diskutera olika �mnen.<BR>
Personangrepp p� andra deltagare kommer inte att tolereras.<BR>
Tr�darna som l�ggs upp i forumet skall ha n�gon anknytning till n�tt av VM, EM, tippning, resultat, hemsidan, eller deltagare.<BR>
<BR>
<B>Tvist</B><BR>
Skulle tvist av n�got slag uppst� kommer ansvarig f�r tippningen att avg�ra beslut<BR>
Ansvarigs beslut g�ller oavsett deltagarensvilja<BR>
<BR>
<b>Po�ngs�ttning</b><BR>
<table width="200" border="0">
<tr>
<td width="150">1 X 2</td>
<td>1p</td>
</tr>
<tr>
<td>R�tt kvartsfinallag</td>
<td>2p</td>
</tr>
<tr>
<td>R�tt semifinallag</td>
<td>2p</td>
</tr>
<tr>
<td>R�tt finallag</td>
<td>2p</td>
</tr>
<tr>
<td>R�tt vinnare</td>
<td>5p</td>
</tr>
<tr>
<td>Hur m�nga m�l g�r Sverige</td>
<td>5p</td>
</tr>
<tr>
<td>Vem g�r flest m�l</td>
<td>5p</td>
</tr>
</table>


</td>
</tr>
</table>

<?
} else
	echo 'Permission denied!';
?>