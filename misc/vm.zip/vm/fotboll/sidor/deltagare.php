<table BGCOLOR="#FFFFFF" border="0" width="100%" height="100%">
<tr>
<td align="center" valign="top">
<br>
<span class="rubrik">Deltagare</span>
<br>
<br>
<table border="0">

<?

$nbrCols = 3;
// h�mtar information fr�n den angivna tabellen
$result = mysql_query("SELECT * FROM users ORDER BY username") or die(mysql_error());

// $result2 = mysql_query("SELECT * FROM tippning WHERE ID = '".$row['id']."';"); // H�mtar deltagarens tippning fr�n databasen.

// h�mtar resultatrader fr�n tabellen
$id = 0;
echo '<tr align="left">';
while($row = mysql_fetch_array( $result ))
     { 
     // skriver ut inneh�llet i raderna till HTML-tabellen
	 
	 
	if ($id % $nbrCols == 0)
		echo '</tr><tr align="left">';
	?>
		<td>
			<!--<a href="index.php?sida=deltagare&id=<?=$row['id'];?>">-->
			<table border="0" cellspacing="0" cellpadding="0" onclick="document.location='index.php?sida=visadeltagare&id=<?=$row['id'];?>';" style="cursor: pointer; cursor: hand;">
			<tr>
				<td width="250" colspan="3">
				<div class="roundtop">
				<div class="r1"></div>
				<div class="r2"></div>
				<div class="r3"></div>
				<div class="r4"></div>
				<div class="r5"></div>
				</div>
				</td>
			</tr>
			
			<tr bgcolor="#cb2725" align="left">
				<td width="5">
				</td>
				
				<td width="55" height="50">
				<img src="./pic/users/<?=$row['foto'];?>" width="50" height="50">
				</td>
			
				<td width="175">
				<b><?=$row['user'];?></b><br>
				<?=$row['givenName'], '&nbsp;', $row['familyName'];?><br>
				<?=$row['city'];?><br>
				<?=$row['Company'];?>
				<?/*
				if(mysql_num_rows($result2) > 0)
				{
				echo '<br>';
				echo 'Tippning OK!';
				}
				*/?>
				</td>
				
			</tr>
			<tr>
				<td colspan="3">
				<div class="roundbottom">
				<div class="r5"></div>
				<div class="r4"></div>
				<div class="r3"></div>
				<div class="r2"></div>
				<div class="r1"></div>
				</div>
				</td>
			</tr>
			</table>
			<!--</a>-->
			
			</td>
	<?


	$id++;
     }
// HTML-tabellens formatering - tabellslut
?>
</table>

</td>
</tr>
</table>
