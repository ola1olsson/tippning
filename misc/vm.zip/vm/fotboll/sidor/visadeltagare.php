<table BGCOLOR="#FFFFFF" border="0" width="100%" height="100%">
<tr>
<td align="center" valign="top">
<br>
<span class="rubrik">Visa deltagare</span>
<br>
<br>

<?
$grundspel = Array('A','B','C','D'/*,'E','F','G','H'*/);

$max_grupp = 24;
$max_slut = 31;


if($_REQUEST['id'] != '')
{
	// h�mtar information fr�n den angivna tabellen
	$result = mysql_query("SELECT * FROM users WHERE id = '".$_REQUEST['id']."';") or die(mysql_error());	// H�mta alla v�rden fr�n tabellen "deltagare" d�r "id" �r lika med "request id". D�r request id" �r anv�ndaren du vill titta p�.
	$row = mysql_fetch_array($result, MYSQL_ASSOC);
		 // skriver ut inneh�llet i raderna till HTML-tabellen
		 
		 
//--------------------H�mta anv�ndarens tippning fr�n databasen------------------------------------- START - Anv�nds inte �nnu... vet inte om det kommer att anv�ndas.
/*
	// DATABASE CONNECTION ESTABLISHMENT
	$db_result = mysql_query("SELECT * FROM tippning WHERE id = '".$_REQUEST['id']."';") or die(mysql_error());		// H�mta alla v�rden fr�n tabellen "tippning" d�r "id" �r lika med "request id". D�r request id" �r anv�ndaren du vill titta p�.

	$db_result = mysql_query($query);								// vet inte om "mysql_query" ska vara med h�r... n�tt �r riktigt fucked h�r!!!! Tar man bort denna raden blir det helevete!!!
	while($db_res = mysql_fetch_array($db_result, MYSQL_ASSOC)) {
		for($i=1; $i<=$max_grupp; $i++) {
			$result[$db_res['id']][$i] = $db_res['m'.$i];			// H�mta resultat i gruppspelet
		}
		for($i=$max_grupp + 1; $i<=$max_slut; $i++) {
			$result[$db_res['id']][$i][0] = $db_res['m'.$i];		// H�mta resultat i slutspelet
			$result[$db_res['id']][$i][1] = $db_res['m'.$i.'a'];	// H�mta hemmalag i slutspelet fr�n anv�ndarens tippning
			$result[$db_res['id']][$i][2] = $db_res['m'.$i.'b'];	// H�mta bortalag i slutspelet fr�n anv�ndarens tippning
		}
		$result[$db_res['id']][$max_slut + 1] = $db_res['m'.($max_slut + 1)];				// H�mta resultat "Vem vinner EM2008?"
		$result[$db_res['id']][$max_slut + 2] = $db_res['m'.($max_slut + 2)];				// H�mta resultat "Hur m�nga m�l g�r Sverige?"
		$result[$db_res['id']][$max_slut + 3][0] = $db_res['m'.($max_slut + 3).'a'];			// H�mta resultat "Vilken spelare g�r flestm�l?"
		$result[$db_res['id']][$max_slut + 3][1] = $db_res['m'.($max_slut + 3).'b'];			// H�mta resultat "Och han spelar f�r landet?"
	}
*/
//--------------------H�mta anv�ndarens tippning fr�n databasen------------------------------------- SLUT
		 

//--------------------Skriv ut anv�ndarens uppgifter fr�n databasen------------------------------------- START
	?>	 

	<table border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="465" colspan="3">
			<div class="roundtop">
			<div class="r1"></div>
			<div class="r2"></div>
			<div class="r3"></div>
			<div class="r4"></div>
			<div class="r5"></div>
			</div>
			</td>
		</tr>
		
		<tr bgcolor="#cb2725" align="left">
			<td width="5">
			</td>
			
			<td width="155" height="150">
			<img src="./pic/users/<?=$row['foto'];?>" width="150" height="150">
			</td>
		
			<td width="300" align="center">
				<table border="0" width="290">
				<tr>
					<td colspan="2" align="center"><h2><b><?=$row['user'];?></b></h2></td>
				</tr>
				<tr>
					<td align="right">
					Namn:<br>
					Ort:<br>
					F�retag:<br>
					Telefon:<br>
					E-post:<br>
					</td>
					<td>
					<?=$row['givenName'], '&nbsp;', $row['familyName'];?><br>
					<?=$row['city'];?><br>
					<?=$row['Company'];?><br>
					<?=$row['phoneNumber'];?><br>
					<?=$row['emailAddress'];?><br>
					</td>
				</tr>
				</table>
			</td>
			
		</tr>
		<tr>
			<td colspan="3">
			<div class="roundbottom">
			<div class="r5"></div>
			<div class="r4"></div>
			<div class="r3"></div>
			<div class="r2"></div>
			<div class="r1"></div>
			</div>
			</td>
		</tr>
	</table>
	
	<br>
	
	<?
//--------------------Skriv ut anv�ndarens uppgifter fr�n databasen------------------------------------- SLUT	
	
//--------------------Kollar om anv�ndaren har en tippning registrerad i databasen------------------------------------- START

	// HITTA USER'ns tippning
	$result = mysql_query("SELECT * FROM tippning WHERE ID = '".$row['id']."';"); // H�mtar deltagarens tippning fr�n databasen.
	if(mysql_num_rows($result) > 0)
	{
		echo '<br>';
		echo $row['user'].' har en registrerad tippning!<br/><br/>';
		$correct = mysql_query("SELECT * FROM tippning WHERE ID = '0';"); 	// H�mtar den r�tta raden i tippningen
		$corr = mysql_fetch_array($correct, MYSQL_ASSOC);					// L�gger in den r�tta raden i en Array
		$row = mysql_fetch_array($result, MYSQL_ASSOC);						// L�gger in deltagarens tippnings rad i en Array
	}
	else
	{
		echo $row['user'].' har inte tippat �nnu!<br><br>';
	}
	
	
/*			T�nkte mig att detta kunde bli en funktion f�r att r�kna ut resultat. S� h�r l�ngt kom jag.	
Function()
	$rattrad = $corr['m'.$match['id']];
	$deltagaretipp = $row['m'.$match['id']];
*/	
	
	
	
//--------------------Kollar om anv�ndaren har en tippning registrerad i databasen------------------------------------- SLUT	
	
} else {
	echo 'Nu �r det fel p� sidan igen! Ge mig ett anv�ndar-id f�r h-vete!';
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Fr�n och med 2008-06-01 f�r anv�ndarna till�telse att se dem andras tippning. Eller s� �r du admin och f� se allt innan.
if(session_is_registered('permission') && $_SESSION['permission'] && $_SESSION['betalt'] == 1 && (date('Y-m-d')>$last_bet_day || $_SESSION['admin'])) {

//--------------------H�r under f�rs�ker jag skriva ut anv�ndarens tippning lite snyggt i en tabell------------------------------------- START

?>
<br>
<br>
<br>
	<table border="0" cellspacing="0" cellpadding="0">
	<tr class="rubrik">
		<td align="center">Match</td>
		<td align="center" width="100">Hemma</td>
		<td align="center">-</td>
		<td align="center" width="100">Borta</td>
		<td>
			<table border="1" bordercolor="black" cellspacing="0" cellpadding="0">
			<tr class="rubrik">
				<td align="center" width="20" height="20">1</td>
				<td align="center" width="20" height="20">X</td>
				<td align="center" width="20" height="20">2</td>
			</tr>
			</table>
		</td>
		<td align="center" width="50">Po�ng</td>
	</tr>
	
	<? // Gruppspelet, visar - s� h�r har deltagaren tippat.
foreach($grundspel AS $grupp) {
	$matcher = mysql_query("SELECT * FROM matcher WHERE hemma LIKE '".$grupp."%' AND borta LIKE '".$grupp."%' ORDER BY ID ASC;");
?>	
		<tr><td colspan=7><span class="rubrik2">Grupp <?echo $grupp;?></span></td></tr>
		<?
		while($match = mysql_fetch_array($matcher)) {
		$hemma = mysql_fetch_array(mysql_query("SELECT * FROM lag WHERE lag = '".$match['hemma']."';"), MYSQL_ASSOC);
		$borta = mysql_fetch_array(mysql_query("SELECT * FROM lag WHERE lag = '".$match['borta']."';"), MYSQL_ASSOC);
		?>
			<tr>
			<td valign="center" align="center"><?=$match['id']?></td>
			<td valign="center" align="right"><?=$hemma['land'] ?>&nbsp;<img src="./pic/flaggor/<?=$hemma['flagga']?>" align="absmiddle"></td>
			<td valign="center" align="center"> - </td>
			<td valign="center" align="left"><img src="./pic/flaggor/<?=$borta['flagga'] ?>" align="absmiddle">&nbsp;<?=$borta['land']?></td>
			<td>
				<table border="0" bordercolor="black" cellspacing="0" cellpadding="0">
				<tr>
					<?
						$tmp_c = $corr['m'.$match['id']];
						$tmp_r = $row['m'.$match['id']];
					?>
					<td align="center" width="20" height="20" <? if($tmp_r == '1') { if($tmp_c == '1') echo 'bgcolor=#00ff00;'; else echo 'bgcolor=#ff0000;'; } ?>><? if($tmp_r == '1') echo '1'; ?></td>
					<td align="center" width="20" height="20" <? if($tmp_r == 'X') { if($tmp_c == 'X') echo 'bgcolor=#00ff00;'; else echo 'bgcolor=#ff0000;'; } ?>><? if($tmp_r == 'X') echo 'X'; ?></td>
					<td align="center" width="20" height="20" <? if($tmp_r == '2') { if($tmp_c == '2') echo 'bgcolor=#00ff00;'; else echo 'bgcolor=#ff0000;'; } ?>><? if($tmp_r == '2') echo '2'; ?></td>
				</tr>
				</table>
			</td>
			<td align="center"><? if($tmp_r == '1') { if($tmp_c == '1') echo '1p'; else echo ''; } 
							  elseif($tmp_r == 'X') { if($tmp_c == 'X') echo '1p'; else echo ''; } 
							  elseif($tmp_r == '2') { if($tmp_c == '2') echo '1p'; else echo ''; } ?>
			</td>			
		</tr>
	<?		
	}
	?>
	<tr><td colspan=7 align="center"><hr align="center" style="width:96%; height:2px;" color="#6C261F"></td></tr>
<?	
}
?>
</table>

<?} else // IF DATE IS OUT OF DATE
	echo '<center>Fr�n och med <?=$last_bet_day?> kommer du<br>att kunna se deltagarens tippning.</center>';
?>

</td>
</tr>
</table>