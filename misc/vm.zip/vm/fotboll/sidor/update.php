

<?

if($_SESSION['admin']) {

echo '<table BGCOLOR="#FFFFFF" width="100%" height="100%"  bordercolor="#6C261F"  cellpadding="30" cellspacing="0">';
echo '<tr>';
echo '<td align="left" valign="top" frame="rhs" border="1"> ';
echo '<center><span class="rubrik">Uppdatering av po�ngst�llning</span></center><br>';

	
	
	$correctTip = mysql_fetch_array(mysql_query("SELECT * FROM tippning WHERE id = '0';"), MYSQL_ASSOC) or die(mysql_error());
	
	$max_1p = 31;
	
	$min_2p = 25;
	$max_2p = 31;
	
	$start_extra = 32;
	
	echo '<table>';
	
	echo '<tr><td><b>Match</b></td><td><b>User</b></td><td><b>Correct</b></td><td><b>Points</b></td></tr>';
	$usersTips = mysql_query("SELECT * FROM tippning WHERE id != '0';") or die(mysql_error());
	$nbrUsers = mysql_num_rows($usersTips);
	while($userTip = mysql_fetch_array($usersTips, MYSQL_ASSOC)) {
	
		$user = mysql_fetch_array(mysql_query("SELECT * FROM deltagare WHERE id ='".$userTip['id']."';"), MYSQL_ASSOC);
		
		echo '<tr><td colspan="4" bgcolor="#dddddd"><b>'.$user['fornamn'].' '.$user['efternamn'].'</b></td></tr>';
		
		
		$points = 0;
		// 1p f�r r�tt resultat match 1-63
		$points_grundspel = 1;
		for($k = 1; $k<=$max_1p; $k++) {
			echo '<tr><td>m'.$k.'</td><td>'.$userTip['m'.$k].'</td><td>'.$correctTip['m'.$k].'</td>';
			if($userTip['m'.$k] == $correctTip['m'.$k] && $userTip['m'.$k] != '') 
			{
				$points = $points + $points_grundspel;
				echo '<td bgcolor="#00ff00">'.$points_grundspel.'p</td>';
			}
			else
			{
				echo '<td></td>';
			}
			echo '</tr>';
		}
		// 2p - R�tt tippad �ttondels-, kvarts-, semi- eller tredjeplatslag, (och final just nu)
		$points_slutspel = 2;
		for($k =$min_2p; $k<=$max_2p; $k++) {
			echo '<tr><td>m'.$k.'a</td><td>'.$userTip['m'.$k.'a'].'</td><td>'.$correctTip['m'.$k.'a'].'</td>';
			if($userTip['m'.$k.'a']==$correctTip['m'.$k.'a'] && $userTip['m'.$k.'a']!='') 
			{
				$points = $points + $points_slutspel;
				echo '<td bgcolor="#00ff00">'.$points_slutspel.'p</td>';
			}
			else
			{
				echo '<td></td>';
			}
			echo '</tr>';
			
			echo '<tr><td>m'.$k.'b</td><td>'.$userTip['m'.$k.'b'].'</td><td>'.$correctTip['m'.$k.'b'].'</td>';
			if($userTip['m'.$k.'b']==$correctTip['m'.$k.'b'] && $userTip['m'.$k.'b']!='')
			{
				$points = $points + $points_slutspel; 
				echo '<td bgcolor="#00ff00">'.$points_slutspel.'p</td>';
			}
			else
			{
				echo '<td></td>';
			}
			echo '</tr>';
			
		}
		
		// 5p - R�tt vinnare
		$points_extra = 5;
		echo '<tr><td>m'.$start_extra.'a</td><td>'.$userTip['m'.$start_extra.'a'].'</td><td>'.$correctTip['m'.$start_extra.'a'].'</td>';
		if($userTip['m'.$start_extra.'a']==$correctTip['m'.$start_extra.'a']&&$userTip['m'.$start_extra.'a']!='')
		{
			$points = $points + $points_extra;
			echo '<td bgcolor="#00ff00">'.$points_extra.'p</td>';
		}
		else
		{
			echo '<td></td>';
		}
		echo '</tr>';
		
		// 5p - R�tt antal m�l som Sverige g�r under hela VM
		echo '<tr><td>m'.($start_extra + 1).'a</td><td>'.$userTip['m'.($start_extra + 1).'a'].'</td><td>'.$correctTip['m'.($start_extra + 1).'a'].'</td>';
		if($userTip['m'.($start_extra + 1).'a']==$correctTip['m'.($start_extra + 1).'a']&&$userTip['m'.($start_extra + 1).'a']!='')
		{
			$points = $points + $points_extra;
			echo '<td bgcolor="#00ff00">'.$points_extra.'p</td>';
		}
		else
		{
			echo '<td></td>';
		}
		echo '</tr>';
			
		//5p - R�tt person (och lag) som g�r flest m�l under hela VM
		echo '<td>m'.($start_extra + 2).'a</td><td>'.$userTip['m'.($start_extra + 2).'a'].'</td><td>'.$correctTip['m'.($start_extra + 2).'a'].'</td>';
		if($userTip['m'.($start_extra + 2).'a']==$correctTip['m'.($start_extra + 2).'a']&&$userTip['m'.($start_extra + 2).'b']==$correctTip['m'.($start_extra + 2).'b']&&$userTip['m'.($start_extra + 2).'a']!='')
		{
			$points = $points + $points_extra;
			echo '<td bgcolor="#00ff00">'.$points_extra.'p</td>';
		}
		else
		{
			echo '<td></td>';
		}
		echo '</tr>';
			
		echo '<tr><td colspan="3" bgcolor="#dddddd"><b>Total points:</b></td><td bgcolor="#dddddd"><b>'.$points.'p</b></td></tr>';
		echo '<tr><td colspan="4"></td></tr>';
		mysql_query("UPDATE deltagare SET points = '".$points."' WHERE id = '".$userTip['id']."';") or die(mysql_error());
	}
	echo '<table>';
	echo $nbrUsers.'st deltagares po�ngst�llning har uppdaterats.<br><br><input type=button class=btn value="Startsidan" onClick="document.location=\'index.php?sida=startsida\';">';
	
echo '</td>';
echo '</tr>';
echo '</table>';
	
} else { 
	echo 'Permission denied!';
}

?>