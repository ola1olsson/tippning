<?php

// Variabler f�r inloggningsuppgifter

// Hostnamn p� MySQL-server
$dbhost = "thoka.se.mysql";

// Anv�ndarnamn p� MySQL-servern
$dbuser = "thoka_se";

// L�senord p� MySQL-servern
$dbpass = "thoka10513578";

// Databas namn p� databasen du vill komma �t p� MySQL-servern
$dbname = "thoka_se";

$last_bet_day = "2010-06-11";

$price = "20";

$swe = 1;

// All variables are named like "pagename_variablename", the .php extension is omitted
$language				= 'swe';
$registrera_contract 	= 'NOT INITILIZED'; // The rules that must be accepted before entering the page
$regler_rules	  		= 'NOT INITILIZED'; // How points are given
if ($language == 'swe')
{
	$registrera_contract = 'dolme';
	$regler_rules	  = 'kodd';
}
else if ($language == 'eng')
{
	$contract = 'dick';
	$regler_rules	  = 'hola guapa';
}
?>