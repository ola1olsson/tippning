<?

/*
if($page == 'login') {
	$result = mysql_query("SELECT * FROM users WHERE username = '".$_POST['user']."' AND password = '".$_POST['pass']."';") or die(mysql_error());
	
	
	if($row = mysql_fetch_array($result,MYSQL_ASSOC)) {
		$_SESSION['user'] = $row['user'];
		$_SESSION['userID'] = $row['ID'];
		$_SESSION['permission'] = 1;
		if($row['admin'] == 'Y') 
			$_SESSION['admin'] = 1;
		else 
			$_SESSION['admin'] = 0;
		$_SESSION['payed'] = $row['betalt'];	
	}
	$page = 'default';
} else if($page == 'logout') {
	$_SESSION['permission'] = 0;
	session_destroy();
	$page = 'default';
	
*/	
	


session_start();
if($_GET['sida'] != '')
{
	$page = $_GET['sida'];
}
else
{
	$page = 'startsida';
}

//Inkluderar kopplingen till databasen.
include "config.php";
include "connect_database.php";


// Kollar om formul�ret �r skickat, dvs om taggen HIDDEN �r skickad med POST
if($_POST['register'] == 'true')
{
	//if($_POST['username'] == 'waldis' && $_POST['password'] == 'nisse')
	
	$result = mysql_query("SELECT * FROM users WHERE username = '".addslashes($_POST['username'])."' AND password = '".md5(addslashes($_POST['password']))."';") or die(mysql_error());
	if($row = mysql_fetch_array($result,MYSQL_ASSOC)) {
	
		// S�tter permission till 1, vilket inneb�r att anv�ndaren �r inloggad godk�nt och f�ljande h�ndelser intr�ffar
		// $logstatus = "Du �r inloggad som ".$_POST['username'];
		$_SESSION['user'] = $row['username'];
		$_SESSION['userID'] = $row['id'];
		$_SESSION['foto'] = $row['foto'];
		$_SESSION['betalt'] = $row['betalt'];
		$_SESSION['permission'] = 1;
		$_SESSION['admin'] = $row['admin'];
		if ($_SESSION['username'] == 'ola')
		{
			$_SESSION['admin'] = 1;
		}
		//REMOVE
		$_SESSION['admin'] = 1;
		$_SESSION['betalt'] = 1;
		//REMOVE
}
	else // om inloggningsuppgifterna �r felaktiga intr�ffar f�ljande
	{
		$logstatus = "Felaktiga inloggningsuppgifter";
		$_SESSION['permission'] = 0;
	}
}

if($_GET['command'] == 'logout')
{
	$logstatus = "Du �r nu utloggad!";
	$_SESSION['username'] = '';
	
	// session_stop() eller session_close() <-- tror det �r close
	$_SESSION['permission'] = 0; // ta bort accessen
	session_destroy(); // F�rst�r sessionen
}
?>

<html>

<head>

<title>Sida = <?=$page?></title>
<link href="css\styles.css" rel="stylesheet" type="text/css">
</head>

<body>



<?
if($_SESSION['permission'] == 1)
{
	?>
	<center>
	<table width="900" height="100%" cellspacing="0" cellpadding="0">
	<tr valign="bottom">
	<td colspan="2" height="95" cellspacing="0" cellpadding="0" border="0" background="pic\logo.gif" style="background-repeat: no-repeat;" align="left">
<?
/**	Visar sida <_? =$page ?_><br><br>
	
	<a href="index.php?sida=startsida">Startsidan</a> | 
	<a href="index.php?sida=sida2">Sida2</a> |
	<a href="index.php?sida=sida3">Sida3</a> |
	<a href="index.php?sida=sida4">Sida4</a> |
	<a href="index.php?command=logout">Logga ut</a> |
**/	
 ?>	
<div id="menycontainer">
<ul style="position: relative; left: 200px;">
    <li><a class="mainmenu" href="index.php?sida=startsida"
		<?
				if ($page == 'startsida')
				{
				echo 'id="current"';
				}
		?>
		>Startsida</a></li>
		<li><a class="mainmenu" href="index.php?sida=matcher"
		<?
				if ($page == 'matcher')
				{
				echo 'id="current"';
				}
		?>
		>Matcher</a></li>

		<li><a class="mainmenu" href="index.php?sida=deltagare"
		<?
				if ($page == 'deltagare')
				{
				echo 'id="current"';
				}
		?>
		>Deltagare</a></li>
		
<?if(date('Y-m-d')<$last_bet_day) {
		echo '<li><a class="mainmenu" href="index.php?sida=tippning"';
				if ($page == 'tippning')
				{
				echo 'id="current"';
				}
		
		echo '>Tippning</a></li>';
		}
?>
<?
if(date('Y-m-d')>$last_bet_day || $_SESSION['admin']) {
		echo '<li><a class="mainmenu" href="index.php?sida=resultat"';
				if ($page == 'resultat')
				{
				echo 'id="current"';
				}
		
		echo '>Resultat</a></li>';
		}
?>
		<li><a class="mainmenu" href="index.php?sida=regler"
		<?
				if ($page == 'regler')
				{
				echo 'id="current"';
				}
		?>
		>Regler</a></li>

		<li><a class="mainmenu" href="index.php?sida=forum"
		<?
				if ($page == 'forum')
				{
				echo 'id="current"';
				}
		?>
		>Forum</a></li>
	</ul>
	</div>
	</td>
	</tr>
	<tr>
	<td border="1" bordercolor="#6C261F" width="150" bgcolor="#cb2725" >
		<table border="1" frame="vsides" frame="above" bordercolor="#6C261F" height="100%" width="100%" cellpadding="0" cellspacing="0">
		<tr valign="top" align="center">
			<td>
			<br><br>
				<table border="2" bordercolor="#6C261F" height="145" width="125" cellpadding="5" cellspacing="0">
				<tr align="center">
					<td><img src="./pic/users/<?=$_SESSION['foto'];?>" width="110" height="110"><br><br>
					<b><?=$_SESSION['user']?></b><br><br>
					<?if($_SESSION['admin']) echo '<span style="color:#FFFFFF; font-weight:bold;">Administrator</span><br><br>';?>
					<a href="index.php?sida=profil">Min Profil</a><br>
					
					<?if(date('Y-m-d')<$last_bet_day) {
						echo '<a href="index.php?sida=tippning">Min Tippning</a><br>';
					}
			/*		else {
						echo '<a href="index.php?sida=visadeltagare&id'.$_SESSION['userID']'">Min Tippning</a><br>';
					} */
?>
					<a href="index.php?command=logout">Logga ut</a><br><br>
					<?if($_SESSION['admin']) echo '<span style="color:#550000; font-weight:bold;"><a href="index.php?sida=usertip">Anv�ndar Info</a></span><br><br>';?>
					<?if($_SESSION['admin']) echo '<span style="color:#550000; font-weight:bold;"><a href="index.php?sida=update">Uppdatera Po�ng</a></span><br><br>';?>
					</td>
				</tr>
				</table>
				<br>
				<br>
				<table border="2" bordercolor="#6C261F" height="145" width="125" cellpadding="5" cellspacing="0">
				<tr>
					<td>
						<?include './sidor/halloffame.php';?>
					</td>
				</tr>
				</table>
			</td>
			
		</tr>
		</table>
	</td>
	<td width="750">
	<form method="POST" name="verify" enctype="multipart/form-data" id=666 onSubmit="return formCheck(this);">
	<?include('./sidor/'.$page.'.php');?>
	</form>
	</td>
	</tr>
	<tr>
	<td colspan="2" height="20" bgcolor="#6C261F" cellspacing="0" cellpadding="0">
	<span class="copyright">&nbsp;&nbsp;&nbsp;&nbsp;&copy; Copyright 2010 Waldis, Thobias och Ola&nbsp;</span>
	</td>
	</tr>
	</table>
	</center>
	<?
} 
else
//-------------------------------------------- Inloggning ----------------------------
// Hit kommer man om man inte uppfyllt ovanst�ende krav. dvs om man inte har permission=1
{
	?>
	<form action="index.php" method="POST">
	
	<table width="850"  border="5" bordercolor="981a25" align="center">
<tr> 
	<td height="100%">
	

<table width="850" height="600" background="pic\uefa_euro2008_logo.jpg" border="0" bordercolor="black" align="center">
	<tr> 
	<td height="325" colspan=4>
			
		<tr>
		<form action="registrera.php" method="post" name="register">
			<td width="150" height="20"></td>
			<td width="25">Anv�ndarnamn</td>
			<td width="150"><input type="text" name="username" style="width:145px;"></td>
			<td></td>
		</tr>
		<tr>
			<td width="150" height="20"></td>
			<td width="25">L�senord</td>
			<td width="150"><input type="password" name="password" style="width:145px;"></td>
			<td></td>
		</tr>
		<tr>
			<td width="150" height="25"></td>
			<td width="25"></td>
			<td width="150"><input type="hidden" name="register" value="true"><input type="submit" class="btn" value="Logga in"></td>
			<td></td>
		</tr>
		</form>
		
		<tr>
			<td width="150" height="25"></td>
			<td width="25"></td>
			<td width="150">
		<?
		if(date('Y-m-d')<$last_bet_day) {
		echo '<a href="registrera.php">Registrera ny anv�ndare</a>';
		}
		?>
			</td>
			<td></td>
		</tr>
			<td width="150" height="25"></td>
			<td width="25"></td>
			<td height="60"><H4><B><?=$logstatus?></B></H3></td>
		</tr>
		<tr>
		<td height="100%" colspan=4></td>
		</tr>
	</td>
	</tr>
</table>

</td>
</tr>
</table>

	<?
//--------------------------------------------------------- Slut p� inloggningen --------------------------------------------------------	
}

// st�nger databasen
mysql_close($opendb);

?>

</body>

</html>